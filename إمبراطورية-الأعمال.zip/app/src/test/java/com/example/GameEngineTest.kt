package com.example

import com.example.game.model.GameState
import com.example.game.model.StoryStep
import com.example.game.model.TimeOfDay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {

    @Test
    fun initialState_hasCorrectInheritanceData() {
        val state = GameState()
        assertEquals(1, state.day)
        assertEquals(TimeOfDay.MORNING, state.timeOfDay)
        assertEquals(250L, state.cash)
        assertEquals("دكان الخضار والفواكه القديم", state.store.nameAr)
        assertEquals(3, state.store.equipments.size)
        assertEquals(10, state.inventory.size)
        assertEquals(StoryStep.PROLOGUE_CALL, state.storyStep)
        assertNotNull(state.activeDialogue)
        assertTrue(state.dailyLogs.isNotEmpty())
    }

    @Test
    fun inventoryItems_containRequiredTenArabicProducts() {
        val state = GameState()
        val names = state.inventory.map { it.nameAr }
        val requiredProducts = listOf(
            "بطاطا",
            "طماطم",
            "بصل",
            "جزر",
            "خيار",
            "تفاح",
            "موز",
            "برتقال",
            "فراولة",
            "بطيخ"
        )
        for (product in requiredProducts) {
            assertTrue("Inventory must contain $product", names.contains(product))
        }
    }

    @Test
    fun inventoryItems_haveValidPricesAndStock() {
        val state = GameState()
        for (item in state.inventory) {
            assertTrue("Retail price must be higher than wholesale price", item.retailPrice > item.wholesalePrice)
            assertTrue("Stock should not exceed capacity", item.currentStock <= item.maxCapacity)
        }
    }

    @Test
    fun storyScenes_areCompleteAndProperlySequenced() {
        val scenes = com.example.game.model.createDefaultStoryScenes()
        assertEquals(5, scenes.size)
        // Verify scene flow covers the story: countryside, call, travel, store, determined
        assertTrue(scenes[0].textAr.contains("الريف"))
        assertTrue(scenes[1].textAr.contains("مكالمة") || scenes[1].textAr.contains("هاتفي"))
        assertTrue(scenes[2].textAr.contains("وصية") && scenes[2].textAr.contains("المدينة"))
        assertTrue(scenes[3].textAr.contains("دكان") && scenes[3].textAr.contains("خضار"))
        assertTrue(scenes[4].textAr.contains("أستسلم") || scenes[4].textAr.contains("التجارة"))

        for (scene in scenes) {
            assertEquals("التالي", scene.buttonTextAr)
            assertTrue(scene.titleAr.isNotEmpty())
            assertTrue(scene.sceneBadgeAr.isNotEmpty())
        }
    }

    @Test
    fun storeScreen_hasRequiredSubScreens() {
        val screens = com.example.game.engine.GameScreen.values()
        assertTrue(screens.contains(com.example.game.engine.GameScreen.STORE))
        assertTrue(screens.contains(com.example.game.engine.GameScreen.BUY_GOODS))
        assertTrue(screens.contains(com.example.game.engine.GameScreen.INVENTORY))
        assertTrue(screens.contains(com.example.game.engine.GameScreen.EMPLOYEES))
        assertTrue(screens.contains(com.example.game.engine.GameScreen.STORE_UPGRADE))
        assertTrue(screens.contains(com.example.game.engine.GameScreen.REPORTS))
    }
}
