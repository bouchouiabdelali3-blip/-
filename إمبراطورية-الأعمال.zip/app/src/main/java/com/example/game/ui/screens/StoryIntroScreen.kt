package com.example.game.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.game.model.StoryScene
import com.example.game.model.createDefaultStoryScenes

@Composable
fun StoryIntroScreen(
    onFinishStoryIntro: () -> Unit,
    modifier: Modifier = Modifier,
    scenes: List<StoryScene> = remember { createDefaultStoryScenes() }
) {
    // 0..scenes.size (حيث scenes.size يمثل شاشة الخاتمة وإعلان المهمة الأولى)
    var currentSceneIndex by remember { mutableIntStateOf(0) }
    val isConclusion = currentSceneIndex >= scenes.size

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_story_intro")
    ) {
        // العرض الحركي للمشاهد وصور الخلفية ثنائية الأبعاد
        AnimatedContent(
            targetState = currentSceneIndex,
            transitionSpec = {
                (slideInHorizontally { width -> -width } + fadeIn()) togetherWith
                        (slideOutHorizontally { width -> width } + fadeOut())
            },
            label = "story_scene_animation",
            modifier = Modifier.fillMaxSize()
        ) { targetIndex ->
            if (targetIndex < scenes.size) {
                val scene = scenes[targetIndex]
                StorySceneView(
                    scene = scene,
                    currentIndex = targetIndex,
                    totalScenes = scenes.size,
                    onNext = { currentSceneIndex++ },
                    onSkip = { currentSceneIndex = scenes.size }
                )
            } else {
                StoryConclusionView(
                    onStartStore = onFinishStoryIntro
                )
            }
        }
    }
}

/**
 * عرض مشهد قصصي مفرد مع الصورة التوضيحية والنص وزر التالي
 */
@Composable
private fun StorySceneView(
    scene: StoryScene,
    currentIndex: Int,
    totalScenes: Int,
    onNext: () -> Unit,
    onSkip: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // صورة المشهد الفنية 2D
        Image(
            painter = painterResource(id = scene.imageResId),
            contentDescription = scene.titleAr,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // تدرج لوني سينمائي لحماية وضوح النص والعناصر
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x990A140F),
                            Color(0x220A140F),
                            Color(0xBB0A140F),
                            Color(0xF00A140F)
                        )
                    )
                )
        )

        // شريط علوي للمؤشرات والتخطي
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // شارة المشهد الحالي
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xCC182C22))
                        .border(1.dp, Color(0xFFD4AF37), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = scene.sceneBadgeAr,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFFFE082),
                        fontWeight = FontWeight.Bold
                    )
                }

                // مؤشرات الدوائر للمشاهد
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 0 until totalScenes) {
                        val isActive = i == currentIndex
                        Box(
                            modifier = Modifier
                                .size(if (isActive) 10.dp else 8.dp)
                                .clip(CircleShape)
                                .background(if (isActive) Color(0xFFD4AF37) else Color(0x66FFFFFF))
                        )
                    }
                }
            }

            // زر التخطي السريع
            OutlinedButton(
                onClick = onSkip,
                modifier = Modifier.testTag("btn_story_skip"),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0x66000000),
                    contentColor = Color(0xFFECEFF1)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x88FFFFFF))
            ) {
                Icon(
                    imageVector = Icons.Default.FastForward,
                    contentDescription = "تخطي",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "تخطي القصة",
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }

        // صندوق الحوار السردي السينمائي في الجزء السفلي
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_story_dialogue"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xEE122218)
                ),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0x99D4AF37)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // النص والعنوان
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 16.dp)
                    ) {
                        Text(
                            text = scene.titleAr,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFFFFD54F),
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = scene.textAr,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color(0xFFF1F5F2),
                            lineHeight = 26.sp,
                            modifier = Modifier.testTag("text_story_content")
                        )
                    }

                    // زر "التالي" البارز
                    Button(
                        onClick = onNext,
                        modifier = Modifier
                            .height(52.dp)
                            .testTag("btn_story_next"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                    ) {
                        Text(
                            text = scene.buttonTextAr,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "التالي",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * شاشة خاتمة المقدمة وإعلان بداية الرحلة التجارية والمهمة الأولى
 */
@Composable
private fun StoryConclusionView(
    onStartStore: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // خلفية المتجر والمستقبل التجاري
        Image(
            painter = painterResource(id = R.drawable.story_determined),
            contentDescription = "بداية رحلتك التجارية",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // تدرج داكن فخم للتركيز على بطاقة الهدف
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xCC0E1A14),
                            Color(0xF508110D)
                        )
                    )
                )
        )

        // بطاقة الانطلاق والهدف الأول في منتصف الشاشة الأفقية
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(2.dp, Color(0xFFE5B83B), RoundedCornerShape(24.dp))
                    .testTag("card_story_conclusion"),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFA14251B)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // الجانب الأيمن: شعار وتهنئة البداية
                    Column(
                        modifier = Modifier.weight(1.1f),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE5B83B))
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🏪", fontSize = 22.sp)
                            }

                            Column {
                                Text(
                                    text = "بدأت رحلتك التجارية",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = Color(0xFFFFE082),
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "مرحباً بك في عالم التجارة والأعمال",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFB0BEC5)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // بطاقة إبراز المهمة الأولى
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x33FFD54F))
                                .border(1.5.dp, Color(0xFFD4AF37), RoundedCornerShape(14.dp))
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFFFFD54F),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "المهمة الأولى: قم بتجهيز متجر عمك وابدأ البيع.",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color(0xFFFFF9C4),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.testTag("text_story_mission")
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "تفقّد أجهزة الدكان والرفوف القديمة، ثم انتقل للمخزن لشراء الخضار والفواكه بالمال الذي تركه عمك.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFE0E0E0)
                                )
                            }
                        }
                    }

                    // الجانب الأيسر: زر الدخول والبدء
                    Column(
                        modifier = Modifier.weight(0.7f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Button(
                            onClick = onStartStore,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(58.dp)
                                .testTag("btn_story_start_store"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2E7D32),
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Store,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "دخول المتجر وبدء التجارة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "رأس المال الحالي: 250 ريال نقد 💵",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA5D6A7),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
