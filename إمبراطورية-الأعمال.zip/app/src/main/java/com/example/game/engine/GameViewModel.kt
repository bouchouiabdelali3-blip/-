package com.example.game.engine

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.game.data.GameDatabase
import com.example.game.data.GameRepository
import com.example.game.model.FinancialReport
import com.example.game.model.GameLog
import com.example.game.model.GameState
import com.example.game.model.InventoryItem
import com.example.game.model.Loan
import com.example.game.model.PriceTrend
import com.example.game.model.StoryDialogue
import com.example.game.model.StoryStep
import com.example.game.model.TimeOfDay
import com.example.game.model.createInitialInventory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToLong
import kotlin.random.Random

/**
 * شاشات اللعبة الأساسية
 */
enum class GameScreen {
    MAIN_MENU,      // القائمة الرئيسية
    STORY_INTRO,    // مقدمة القصة والمشاهد السردية
    DASHBOARD,      // لوحة التحكم العامة والريف
    STORE,          // دكان الخضار والفواكه (النشاط التجاري الأول)
    BUY_GOODS,      // شراء البضائع (سوق الجملة)
    INVENTORY,      // المخزون
    EMPLOYEES,      // الموظفون والتوظيف
    STORE_UPGRADE,  // تطوير المتجر والمعدات
    REPORTS,        // التقارير وحركة المبيعات
    BANK,           // البنك والقروض
    PERSONAL_LIFE,  // الحياة الشخصية والصحة
    LOGS            // سجل الأحداث اليومية
}

data class LiveSaleResult(
    val itemNameAr: String,
    val itemEmoji: String,
    val units: Int,
    val revenue: Long,
    val profit: Long,
    val remainingStock: Int
)

/**
 * أنواع الأنشطة الشخصية
 */
enum class LifeActionType {
    REST_NAP,      // قيلولة سريعة
    HEALTHY_MEAL,  // وجبة ريفية مغذية
    VILLAGE_WALK   // جولة ترفيهية في أرجاء القرية
}

data class GameUiState(
    val gameState: GameState = GameState(),
    val currentScreen: GameScreen = GameScreen.MAIN_MENU,
    val hasSavedGame: Boolean = false,
    val toastMessageAr: String? = null,
    val showDailySummary: Boolean = false,
    val showSettingsDialog: Boolean = false
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    init {
        val database = GameDatabase.getDatabase(application)
        repository = GameRepository(database.gameSaveDao())

        // استعلام دوري عن وجود حفظ سابق
        viewModelScope.launch {
            repository.hasSavedGameFlow.collect { hasSave ->
                _uiState.update { it.copy(hasSavedGame = hasSave) }
            }
        }
    }

    /**
     * بدء لعبة جديدة مع بداية القصة والميراث
     */
    fun startNewGame() {
        val freshState = GameState(
            storyStep = StoryStep.PROLOGUE_CALL,
            activeDialogue = null
        )
        _uiState.update {
            it.copy(
                gameState = freshState,
                currentScreen = GameScreen.STORY_INTRO,
                toastMessageAr = "بدأت قصة حياة الأعمال..."
            )
        }
        viewModelScope.launch {
            repository.saveGameState(freshState)
        }
    }

    /**
     * تشغيل مقدمة القصة في أي وقت
     */
    fun playStoryIntro() {
        _uiState.update {
            it.copy(currentScreen = GameScreen.STORY_INTRO)
        }
    }

    /**
     * إنهاء مقدمة القصة والانتقال مباشرة إلى شاشة المتجر للمهمة الأولى
     */
    fun completeStoryIntro() {
        val current = _uiState.value.gameState
        val updatedState = current.copy(
            storyStep = StoryStep.FIRST_DAY_ACTIVE,
            activeDialogue = null,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = "صباحاً",
                    text = "بدأت رحلتك التجارية! المهمة الأولى: قم بتجهيز متجر عمك وابدأ البيع.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )
        _uiState.update {
            it.copy(
                gameState = updatedState,
                currentScreen = GameScreen.STORE,
                toastMessageAr = "بدأت رحلتك التجارية! المهمة الأولى: قم بتجهيز متجر عمك وابدأ البيع."
            )
        }
        viewModelScope.launch {
            repository.saveGameState(updatedState)
        }
    }

    /**
     * متابعة اللعبة المحفوظة
     */
    fun continueSavedGame() {
        viewModelScope.launch {
            val savedState = repository.loadSavedGameState()
            if (savedState != null) {
                val syncedState = savedState.copy(
                    inventory = syncInventoryItems(savedState.inventory)
                )
                _uiState.update {
                    it.copy(
                        gameState = syncedState,
                        currentScreen = GameScreen.DASHBOARD,
                        toastMessageAr = "تم استرجاع تقدمك في اللعبة بنجاح"
                    )
                }
            } else {
                _uiState.update { it.copy(toastMessageAr = "لا يوجد ملف حفظ متاح") }
            }
        }
    }

    /**
     * مزامنة وتحديث قائمة المنتجات لضمان وجود المنتجات الـ 10 الأساسية
     */
    private fun syncInventoryItems(savedInventory: List<InventoryItem>): List<InventoryItem> {
        val initialList = createInitialInventory()
        val existingMap = savedInventory.associateBy { it.id }

        return initialList.map { defaultItem ->
            val existing = existingMap[defaultItem.id]
            if (existing != null) {
                defaultItem.copy(
                    currentStock = existing.currentStock,
                    wholesalePrice = if (existing.wholesalePrice > 0) existing.wholesalePrice else defaultItem.wholesalePrice,
                    retailPrice = if (existing.retailPrice > 0) existing.retailPrice else defaultItem.retailPrice,
                    priceTrend = existing.priceTrend,
                    priceChangePercent = existing.priceChangePercent
                )
            } else {
                defaultItem
            }
        }
    }

    /**
     * حفظ اللعبة يدوياً
     */
    fun saveGame() {
        viewModelScope.launch {
            val success = repository.saveGameState(_uiState.value.gameState)
            if (success) {
                _uiState.update { it.copy(toastMessageAr = "تم حفظ اللعبة بنجاح ✅") }
            } else {
                _uiState.update { it.copy(toastMessageAr = "تعذر حفظ اللعبة، يرجى المحاولة لاحقاً") }
            }
        }
    }

    /**
     * التفاعل مع حوار القصة والمكالمة الهاتفية
     */
    fun onDialogueChoice(choiceIndex: Int) {
        val current = _uiState.value.gameState
        when (current.storyStep) {
            StoryStep.PROLOGUE_CALL -> {
                if (choiceIndex == 0) {
                    // قبول الميراث
                    val nextDialogue = StoryDialogue(
                        speaker = "المحامي سمير",
                        speakerRole = "محامي العائلة",
                        message = "مبارك لك يا بني! مفاتيح دكان الخضار والفواكه ومبلغ 250 ريال أصبحت بيدك الآن. الدكان بحاجة إلى بضائع جديدة وترتيب، لكنه بداية ممتازة لتبني إمبراطوريتك التجارية. بالتوفيق!",
                        primaryButtonAr = "الانطلاق إلى الدكان وبدء العمل"
                    )
                    val updatedState = current.copy(
                        storyStep = StoryStep.INHERITANCE_ACCEPTED,
                        activeDialogue = nextDialogue,
                        dailyLogs = listOf(
                            GameLog(
                                day = current.day,
                                timeAr = "صباحاً",
                                text = "وافقت رسمياً على استلام ميراث العم: دكان الخضار والفواكه ومعداته ومبلغ 250 ريال.",
                                isPositive = true
                            )
                        ) + current.dailyLogs
                    )
                    _uiState.update { it.copy(gameState = updatedState) }
                } else {
                    // قراءة الوصية
                    val willDialogue = StoryDialogue(
                        speaker = "وصية العم صالح",
                        speakerRole = "الوصية المكتوبة",
                        message = "\"إلى ابن أخي العزيز، لم أجد في العائلة من هو أحرص منك على العمل الشريف. أترك لك هذا الدكان البسيط لتبدأ به. اعتنِ بالزبائن، وطوّر معداتك، واحرص على صحتك وراحتك.\"",
                        primaryButtonAr = "استلام الميراث وتفقد الدكان"
                    )
                    _uiState.update { it.copy(gameState = current.copy(activeDialogue = willDialogue)) }
                }
            }
            StoryStep.INHERITANCE_ACCEPTED -> {
                // إغلاق الحوار والدخول في يوم العمل الحر
                val updatedState = current.copy(
                    storyStep = StoryStep.FIRST_DAY_ACTIVE,
                    activeDialogue = null,
                    dailyLogs = listOf(
                        GameLog(
                            day = current.day,
                            timeAr = "صباحاً",
                            text = "فتحت أبواب دكان الخضار والفواكه القديم لأول مرة وبدأت العمل التجاري!",
                            isPositive = true
                        )
                    ) + current.dailyLogs
                )
                _uiState.update { it.copy(gameState = updatedState) }
                saveGame()
            }
            else -> {
                _uiState.update { it.copy(gameState = current.copy(activeDialogue = null)) }
            }
        }
    }

    /**
     * التنقل بين الشاشات
     */
    fun navigateTo(screen: GameScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    /**
     * شراء بضائع للمخزون
     */
    fun buyInventoryStock(itemId: String, quantity: Int) {
        val current = _uiState.value.gameState
        val item = current.inventory.find { it.id == itemId } ?: return
        val totalCost = item.wholesalePrice * quantity

        if (current.cash < totalCost) {
            _uiState.update { it.copy(toastMessageAr = "المال المتوفر لا يكفي لإتمام الشراء!") }
            return
        }

        if (item.currentStock + quantity > item.maxCapacity) {
            _uiState.update { it.copy(toastMessageAr = "المخزن لا يتسع لهذه الكمية الإضافية!") }
            return
        }

        val updatedInventory = current.inventory.map {
            if (it.id == itemId) it.copy(currentStock = it.currentStock + quantity) else it
        }

        val updatedState = current.copy(
            cash = current.cash - totalCost,
            inventory = updatedInventory,
            playerLife = current.playerLife.copy(
                energy = (current.playerLife.energy - 3).coerceAtLeast(5)
            ),
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "شراء $quantity صندوق من ${item.nameAr} بتكلفة $totalCost ريال.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تم شراء $quantity من ${item.nameAr} بنجاح"
            )
        }
    }

    /**
     * شراء سلة بضائع متعددة لمتجر الخضار والفواكه دفعة واحدة
     * يخصم المال ويزيد المخزون ويسجل العملية في سجلات المتجر
     */
    fun buyMultipleItems(purchases: Map<String, Int>): Boolean {
        val validPurchases = purchases.filter { it.value > 0 }
        if (validPurchases.isEmpty()) {
            _uiState.update { it.copy(toastMessageAr = "الرجاء تحديد كمية المنتجات التي ترغب بشرائها!") }
            return false
        }

        val current = _uiState.value.gameState
        var totalCost = 0L
        var totalUnits = 0

        for ((itemId, qty) in validPurchases) {
            val item = current.inventory.find { it.id == itemId } ?: return false
            if (item.currentStock + qty > item.maxCapacity) {
                _uiState.update { it.copy(toastMessageAr = "المخزن لا يتسع لإضافة $qty وحدة من ${item.nameAr}!") }
                return false
            }
            totalCost += item.wholesalePrice * qty
            totalUnits += qty
        }

        if (current.cash < totalCost) {
            _uiState.update { it.copy(toastMessageAr = "المال المتوفر لديك (${current.cash} ريال) أقل من تكلفة الشراء (${totalCost} ريال)!") }
            return false
        }

        val updatedInventory = current.inventory.map { item ->
            val qtyToAdd = validPurchases[item.id] ?: 0
            if (qtyToAdd > 0) {
                item.copy(currentStock = item.currentStock + qtyToAdd)
            } else {
                item
            }
        }

        val detailsList = validPurchases.entries.mapNotNull { (id, qty) ->
            current.inventory.find { it.id == id }?.let { "${it.nameAr}: $qty" }
        }.joinToString("، ")

        val updatedState = current.copy(
            cash = current.cash - totalCost,
            inventory = updatedInventory,
            playerLife = current.playerLife.copy(
                energy = (current.playerLife.energy - 2).coerceAtLeast(5)
            ),
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "توريد بضائع لدكان الخضار والفواكه ($totalUnits وحدة) بتكلفة $totalCost ريال ($detailsList).",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تم شراء $totalUnits وحدة بنجاح وخصم $totalCost ريال! 🛍️"
            )
        }
        return true
    }

    /**
     * ترقية معدات المتجر
     */
    fun upgradeEquipment(equipmentId: String) {
        val current = _uiState.value.gameState
        val eq = current.store.equipments.find { it.id == equipmentId } ?: return

        if (eq.level >= eq.maxLevel) {
            _uiState.update { it.copy(toastMessageAr = "المعدة وصلت إلى الحد الأقصى من الترقية!") }
            return
        }

        if (current.cash < eq.upgradeCost) {
            _uiState.update { it.copy(toastMessageAr = "المال المتوفر لا يكفي لترقية المعدة!") }
            return
        }

        val updatedEquipments = current.store.equipments.map {
            if (it.id == equipmentId) {
                it.copy(
                    level = it.level + 1,
                    upgradeCost = (it.upgradeCost * 1.6).toLong(),
                    customerBonusPercent = it.customerBonusPercent + 15
                )
            } else it
        }

        val newReputation = (current.store.reputation + 8).coerceAtMost(100)
        val newTraffic = current.store.dailyFootTraffic + 5

        val updatedStore = current.store.copy(
            equipments = updatedEquipments,
            reputation = newReputation,
            dailyFootTraffic = newTraffic
        )

        val updatedState = current.copy(
            cash = current.cash - eq.upgradeCost,
            store = updatedStore,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "ترقية ${eq.nameAr} إلى المستوى ${eq.level + 1} بتكلفة ${eq.upgradeCost} ريال.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تمت ترقية ${eq.nameAr} بنجاح وزادت سمعة الدكان!"
            )
        }
    }

    /**
     * محاكاة شراء زبون حي في شاشة المتجر
     */
    fun processLiveCustomerSale(preferredItemId: String? = null): LiveSaleResult? {
        val current = _uiState.value.gameState
        if (!current.store.isOpen) return null

        val inStockItems = current.inventory.filter { it.currentStock > 0 }
        if (inStockItems.isEmpty()) return null

        val targetItem = if (preferredItemId != null) {
            inStockItems.find { it.id == preferredItemId } ?: inStockItems.random()
        } else {
            inStockItems.random()
        }

        val unitsToBuy = if (targetItem.currentStock >= 2 && Random.nextBoolean()) 2 else 1
        val revenue = targetItem.retailPrice * unitsToBuy
        val cost = targetItem.wholesalePrice * unitsToBuy
        val profit = revenue - cost

        val updatedInventory = current.inventory.map { item ->
            if (item.id == targetItem.id) {
                item.copy(currentStock = item.currentStock - unitsToBuy)
            } else {
                item
            }
        }

        val updatedState = current.copy(
            cash = current.cash + revenue,
            inventory = updatedInventory,
            todaySales = current.todaySales + revenue,
            todayProfit = current.todayProfit + profit,
            todayCustomersServed = current.todayCustomersServed + 1,
            totalRevenueEarned = current.totalRevenueEarned + revenue
        )

        _uiState.update { it.copy(gameState = updatedState) }

        return LiveSaleResult(
            itemNameAr = targetItem.nameAr,
            itemEmoji = targetItem.iconEmoji,
            units = unitsToBuy,
            revenue = revenue,
            profit = profit,
            remainingStock = targetItem.currentStock - unitsToBuy
        )
    }

    /**
     * فتح أو إغلاق المتجر
     */
    fun toggleStoreOpen() {
        val current = _uiState.value.gameState
        val newIsOpen = !current.store.isOpen
        val newStore = current.store.copy(isOpen = newIsOpen)
        _uiState.update {
            it.copy(
                gameState = current.copy(store = newStore),
                toastMessageAr = if (newIsOpen) "تم فتح المتجر واستقبال الزبائن 🟢" else "تم إغلاق المتجر مؤقتاً 🔴"
            )
        }
    }

    /**
     * توظيف موظف
     */
    fun hireEmployee(employeeId: String) {
        val current = _uiState.value.gameState
        val emp = current.employees.find { it.id == employeeId } ?: return

        if (emp.isHired) return

        val updatedEmployees = current.employees.map {
            if (it.id == employeeId) it.copy(isHired = true) else it
        }

        val updatedState = current.copy(
            employees = updatedEmployees,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "تم توظيف ${emp.nameAr} كـ (${emp.role.titleAr}) بأجر يومي ${emp.dailyWage} ريال.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تم تعيين ${emp.nameAr} في المتجر"
            )
        }
    }

    /**
     * فصل موظف
     */
    fun fireEmployee(employeeId: String) {
        val current = _uiState.value.gameState
        val emp = current.employees.find { it.id == employeeId } ?: return

        val updatedEmployees = current.employees.map {
            if (it.id == employeeId) it.copy(isHired = false) else it
        }

        val updatedState = current.copy(
            employees = updatedEmployees,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "تم إنهاء خدمات ${emp.nameAr}.",
                    isPositive = false
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تم إنهاء خدمات ${emp.nameAr}"
            )
        }
    }

    /**
     * إيداع في البنك
     */
    fun depositMoney(amount: Long) {
        val current = _uiState.value.gameState
        if (amount <= 0 || current.cash < amount) {
            _uiState.update { it.copy(toastMessageAr = "المبلغ غير صالح أو يفوق المال المتوفر!") }
            return
        }

        val updatedState = current.copy(
            cash = current.cash - amount,
            bankBalance = current.bankBalance + amount,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "إيداع $amount ريال في الحساب البنكي.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(gameState = updatedState, toastMessageAr = "تم إيداع $amount ريال بنجاح")
        }
    }

    /**
     * سحب من البنك
     */
    fun withdrawMoney(amount: Long) {
        val current = _uiState.value.gameState
        if (amount <= 0 || current.bankBalance < amount) {
            _uiState.update { it.copy(toastMessageAr = "رصيد البنك لا يكفي لإتمام السحب!") }
            return
        }

        val updatedState = current.copy(
            cash = current.cash + amount,
            bankBalance = current.bankBalance - amount,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "سحب $amount ريال نقداً من الحساب البنكي.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(gameState = updatedState, toastMessageAr = "تم سحب $amount ريال بنجاح")
        }
    }

    /**
     * الحصول على قرض بنكي لتوسيع التجارة
     */
    fun takeLoan(principal: Long, days: Int) {
        val current = _uiState.value.gameState
        if (current.activeLoan != null) {
            _uiState.update { it.copy(toastMessageAr = "لديك قرض نشط بالفعل! سدده أولاً.") }
            return
        }

        val totalRepay = (principal * 1.15).toLong() // فائدة 15%
        val dailyInstallment = (totalRepay / days).coerceAtLeast(1L)

        val newLoan = Loan(
            id = "loan_${System.currentTimeMillis()}",
            titleAr = "قرض التمويل الزراعي والتجاري الصغير",
            principalAmount = principal,
            totalRepayment = totalRepay,
            remainingAmount = totalRepay,
            dailyInstallment = dailyInstallment,
            totalDays = days,
            daysRemaining = days
        )

        val updatedState = current.copy(
            cash = current.cash + principal,
            activeLoan = newLoan,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "تمت الموافقة على قرض بنكي بقيمة $principal ريال بقسط يومي $dailyInstallment ريال.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تم إيداع مبلغ القرض $principal ريال في صندوقك"
            )
        }
    }

    /**
     * سداد القرض كاملاً
     */
    fun repayLoanFull() {
        val current = _uiState.value.gameState
        val loan = current.activeLoan ?: return

        if (current.cash < loan.remainingAmount) {
            _uiState.update { it.copy(toastMessageAr = "المال المتوفر لا يكفي لسداد باقي القرض!") }
            return
        }

        val updatedState = current.copy(
            cash = current.cash - loan.remainingAmount,
            activeLoan = null,
            dailyLogs = listOf(
                GameLog(
                    day = current.day,
                    timeAr = current.timeOfDay.titleAr,
                    text = "تم سداد القرض البنكي بالكامل بمبلغ ${loan.remainingAmount} ريال وتصفية الالتزام.",
                    isPositive = true
                )
            ) + current.dailyLogs
        )

        _uiState.update {
            it.copy(
                gameState = updatedState,
                toastMessageAr = "تم تسديد القرض بالكامل وإغلاق الحساب"
            )
        }
    }

    /**
     * تنفيذ نشاط حياة شخصية
     */
    fun performLifeAction(action: LifeActionType) {
        val current = _uiState.value.gameState
        val life = current.playerLife

        when (action) {
            LifeActionType.REST_NAP -> {
                val newEnergy = (life.energy + 25).coerceAtMost(100)
                val newTime = advancePeriod(current.timeOfDay)
                val updatedState = current.copy(
                    timeOfDay = newTime,
                    playerLife = life.copy(energy = newEnergy),
                    dailyLogs = listOf(
                        GameLog(
                            day = current.day,
                            timeAr = current.timeOfDay.titleAr,
                            text = "أخذت قيلولة ريفية واستعدت طاقتك بمقدار +25 نقطة.",
                            isPositive = true
                        )
                    ) + current.dailyLogs
                )
                _uiState.update {
                    it.copy(gameState = updatedState, toastMessageAr = "استعدت طاقتك ونشاطك (+25)")
                }
            }
            LifeActionType.HEALTHY_MEAL -> {
                val mealCost = 20L
                if (current.cash < mealCost) {
                    _uiState.update { it.copy(toastMessageAr = "لا تملك مالاً كافياً لشراء هذه الوجبة!") }
                    return
                }
                val updatedState = current.copy(
                    cash = current.cash - mealCost,
                    playerLife = life.copy(
                        health = (life.health + 15).coerceAtMost(100),
                        energy = (life.energy + 15).coerceAtMost(100),
                        happiness = (life.happiness + 10).coerceAtMost(100)
                    ),
                    dailyLogs = listOf(
                        GameLog(
                            day = current.day,
                            timeAr = current.timeOfDay.titleAr,
                            text = "تناولت وجبة طعام ريفية صحية غنية بالخضار بتكلفة $mealCost ريال.",
                            isPositive = true
                        )
                    ) + current.dailyLogs
                )
                _uiState.update {
                    it.copy(gameState = updatedState, toastMessageAr = "تناولت وجبة صحية وتحسنت صحتك وطاقتك")
                }
            }
            LifeActionType.VILLAGE_WALK -> {
                if (life.energy < 10) {
                    _uiState.update { it.copy(toastMessageAr = "أنت متعب جداً للتجول، خذ قسطاً من الراحة أولاً!") }
                    return
                }
                val newTime = advancePeriod(current.timeOfDay)
                val updatedState = current.copy(
                    timeOfDay = newTime,
                    playerLife = life.copy(
                        happiness = (life.happiness + 20).coerceAtMost(100),
                        energy = (life.energy - 10).coerceAtLeast(0)
                    ),
                    dailyLogs = listOf(
                        GameLog(
                            day = current.day,
                            timeAr = current.timeOfDay.titleAr,
                            text = "قمت بنزهة بين المزارع والحقول الريفية مما أدخل البهجة على قلبك (+20 سعادة).",
                            isPositive = true
                        )
                    ) + current.dailyLogs
                )
                _uiState.update {
                    it.copy(gameState = updatedState, toastMessageAr = "نزهة ممتعة في القرية حسنت مزاجك (+20)")
                }
            }
        }
    }

    private fun advancePeriod(time: TimeOfDay): TimeOfDay {
        return when (time) {
            TimeOfDay.MORNING -> TimeOfDay.AFTERNOON
            TimeOfDay.AFTERNOON -> TimeOfDay.EVENING
            TimeOfDay.EVENING -> TimeOfDay.NIGHT
            TimeOfDay.NIGHT -> TimeOfDay.MORNING
        }
    }

    /**
     * إنهاء اليوم ومحاكاة مبيعات المتجر والحسابات المالية
     */
    fun endDayAndSimulate() {
        val current = _uiState.value.gameState

        // 1. حساب مبيعات المتجر
        val bonus = current.store.equipments.sumOf { it.customerBonusPercent }
        val hiredSalesperson = current.employees.find { it.isHired && it.role == com.example.game.model.EmployeeRole.SALES_ASSISTANT }
        val salespersonBonus = hiredSalesperson?.efficiencyPercent ?: 0
        val totalCustomers = (current.store.dailyFootTraffic * (100 + bonus + salespersonBonus / 2) / 100)
            .coerceAtLeast(5)

        var totalGrossSales = 0L
        val updatedInventory = current.inventory.map { item ->
            if (item.currentStock > 0) {
                // عدد المشترين لهذا الصنف
                val demand = Random.nextInt(2, min(item.currentStock + 1, (totalCustomers / 3) + 4))
                val soldCount = min(item.currentStock, demand)
                val itemRevenue = soldCount * item.retailPrice
                totalGrossSales += itemRevenue
                item.copy(currentStock = item.currentStock - soldCount)
            } else {
                item
            }
        }

        // 2. حساب أجور الموظفين
        val wages = current.employees.filter { it.isHired }.sumOf { it.dailyWage }

        // 3. قسط القرض
        var loanPayment = 0L
        var updatedLoan: Loan? = current.activeLoan
        if (updatedLoan != null) {
            loanPayment = min(current.cash + totalGrossSales, updatedLoan.dailyInstallment)
            val remaining = updatedLoan.remainingAmount - loanPayment
            val daysLeft = updatedLoan.daysRemaining - 1
            updatedLoan = if (remaining <= 0 || daysLeft <= 0) {
                null
            } else {
                updatedLoan.copy(remainingAmount = remaining, daysRemaining = daysLeft)
            }
        }

        // 4. مصاريف المعيشة الأساسية
        val livingCost = current.playerLife.dailyFoodCost

        val netProfit = totalGrossSales - wages - loanPayment - livingCost
        val newCash = (current.cash + netProfit).coerceAtLeast(0L)

        // 5. تحديث طاقة اللاعب عند النوم
        val newEnergy = 100
        val newHealth = (current.playerLife.health + 5).coerceAtMost(100)

        val report = FinancialReport(
            day = current.day,
            grossSales = totalGrossSales,
            stockPurchases = 0L,
            wagesPaid = wages,
            loanInstallment = loanPayment,
            livingExpenses = livingCost,
            netProfit = netProfit
        )

        val newDayLog = GameLog(
            day = current.day,
            timeAr = "نهاية اليوم",
            text = "انتهى اليوم ${current.day}: المبيعات $totalGrossSales ريال، الأجور $wages ريال، صافي الربح $netProfit ريال.",
            isPositive = netProfit >= 0
        )

        val dynamicPricedInventory = recalculateMarketDynamicPrices(updatedInventory, current.day + 1)

        val nextDayState = current.copy(
            day = current.day + 1,
            timeOfDay = TimeOfDay.MORNING,
            cash = newCash,
            activeLoan = updatedLoan,
            inventory = dynamicPricedInventory,
            playerLife = current.playerLife.copy(energy = newEnergy, health = newHealth),
            lastFinancialReport = report,
            dailyLogs = listOf(newDayLog) + current.dailyLogs,
            totalRevenueEarned = current.totalRevenueEarned + totalGrossSales,
            daysPlayed = current.daysPlayed + 1,
            todaySales = 0L,
            todayProfit = 0L,
            todayCustomersServed = 0
        )

        _uiState.update {
            it.copy(
                gameState = nextDayState,
                showDailySummary = true,
                toastMessageAr = "بدأ اليوم الجديد ${nextDayState.day} ☀️ (تحديث أسعار سوق الجملة)"
            )
        }

        // حفظ تلقائي في نهاية اليوم
        viewModelScope.launch {
            repository.saveGameState(nextDayState)
        }
    }

    /**
     * نظام الأسعار الديناميكية: حساب تقلبات سوق الجملة اليومية
     * يتيح للأسعار التغير يوماً بيوم بناءً على العرض والطلب وحصاد المزارع
     */
    fun recalculateMarketDynamicPrices(items: List<InventoryItem>, day: Int): List<InventoryItem> {
        val rand = java.util.Random(day.toLong() * 47L + 23L)
        return items.map { item ->
            // نسبة تذبذب بين -20% إلى +25%
            val fluctuationPercent = rand.nextInt(46) - 20
            val trend = when {
                fluctuationPercent <= -10 -> PriceTrend.DISCOUNT
                fluctuationPercent < 0 -> PriceTrend.FALLING
                fluctuationPercent >= 10 -> PriceTrend.RISING
                else -> PriceTrend.STABLE
            }
            val dynamicWholesale = ((item.baseWholesalePrice * (100 + fluctuationPercent)) / 100.0)
                .roundToLong()
                .coerceAtLeast(1L)
            val dynamicRetail = ((item.baseRetailPrice * (100 + (fluctuationPercent / 2))) / 100.0)
                .roundToLong()
                .coerceAtLeast(dynamicWholesale + 1L)

            item.copy(
                wholesalePrice = dynamicWholesale,
                retailPrice = dynamicRetail,
                priceTrend = trend,
                priceChangePercent = fluctuationPercent
            )
        }
    }

    fun dismissDailySummary() {
        _uiState.update { it.copy(showDailySummary = false) }
    }

    fun toggleSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = show) }
    }

    fun resetGame() {
        viewModelScope.launch {
            repository.clearSave()
            _uiState.update {
                it.copy(
                    gameState = GameState(),
                    currentScreen = GameScreen.MAIN_MENU,
                    hasSavedGame = false,
                    showSettingsDialog = false,
                    toastMessageAr = "تم إعادة ضبط اللعبة وحذف البيانات المحفوظة"
                )
            }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessageAr = null) }
    }
}
