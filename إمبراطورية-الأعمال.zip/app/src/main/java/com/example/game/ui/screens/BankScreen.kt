package com.example.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.game.model.Loan

@Composable
fun BankScreen(
    playerCash: Long,
    bankBalance: Long,
    activeLoan: Loan?,
    onDeposit: (Long) -> Unit,
    onWithdraw: (Long) -> Unit,
    onTakeLoan: (Long, Int) -> Unit,
    onRepayLoanFull: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp)
            .testTag("screen_bank"),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // القسم الأيمن: الحساب الجاري والعمليات
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxSize(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Column {
                            Text(
                                text = "بنك الريف للتنمية 🏦",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "حسابك البنكي الآمن لحفظ الأموال والأرباح",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // بطاقة الرصيد
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text("الرصيد البنكي الحالي", style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$bankBalance ريال",
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "النقد في جيبك: $playerCash ريال",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // أزرار الإيداع والسحب السريع
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("عمليات الحساب البنكي السريعة", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onDeposit(50) },
                            enabled = playerCash >= 50,
                            modifier = Modifier.weight(1f).height(40.dp).testTag("btn_deposit_50")
                        ) {
                            Text("إيداع 50 ر", style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { onDeposit(100) },
                            enabled = playerCash >= 100,
                            modifier = Modifier.weight(1f).height(40.dp).testTag("btn_deposit_100")
                        ) {
                            Text("إيداع 100 ر", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onWithdraw(50) },
                            enabled = bankBalance >= 50,
                            modifier = Modifier.weight(1f).height(40.dp).testTag("btn_withdraw_50")
                        ) {
                            Text("سحب 50 ر", style = MaterialTheme.typography.labelSmall)
                        }

                        OutlinedButton(
                            onClick = { onWithdraw(100) },
                            enabled = bankBalance >= 100,
                            modifier = Modifier.weight(1f).height(40.dp).testTag("btn_withdraw_100")
                        ) {
                            Text("سحب 100 ر", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // القسم الأيسر: نظام التمويل والقروض
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxSize(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(26.dp)
                        )
                        Text(
                            text = "نظام القروض والتمويل التجاري 💳",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (activeLoan != null) {
                        // تفاصيل القرض القائم
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = activeLoan.titleAr,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "المبلغ المتبقي: ${activeLoan.remainingAmount} ريال",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFC62828)
                                )
                                Text(
                                    text = "القسط اليومي المقتطع: ${activeLoan.dailyInstallment} ريال/يوم",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "الأيام المتبقية للسداد: ${activeLoan.daysRemaining} يوم",
                                    style = MaterialTheme.typography.bodySmall
                                )

                                val progress = (activeLoan.totalRepayment - activeLoan.remainingAmount).toFloat() / activeLoan.totalRepayment
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    } else {
                        // عرض تقديم القرض الصغير
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "قرض التأسيس الزراعي والتجاري الصغير",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "مبلغ التمويل: 1000 ريال نقداً لترقية المتجر وشراء بضائع.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "فترة السداد: 15 يوماً بقسط يومي ميسر (~76 ريال/يوم).",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                    }
                }

                // إجراء القرض
                if (activeLoan != null) {
                    val canRepayFull = playerCash >= activeLoan.remainingAmount
                    Button(
                        onClick = onRepayLoanFull,
                        enabled = canRepayFull,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("btn_repay_loan_full"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(
                            text = "سداد باقي القرض بالكامل (${activeLoan.remainingAmount} ريال)",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                } else {
                    Button(
                        onClick = { onTakeLoan(1000L, 15) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("btn_apply_loan"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        )
                    ) {
                        Text(
                            text = "طلب قرض 1000 ريال",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
