package com.example.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.game.engine.LifeActionType
import com.example.game.model.PlayerLife

@Composable
fun PersonalLifeScreen(
    playerLife: PlayerLife,
    playerCash: Long,
    onPerformAction: (LifeActionType) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp)
            .testTag("screen_personal_life"),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // القسم الأيمن: المؤشرات الحيوية والمسكن
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxSize(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = null,
                            tint = Color(0xFFE53935),
                            modifier = Modifier.size(26.dp)
                        )
                        Column {
                            Text(
                                text = "الحياة الشخصية والصحة 🌿",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "التوازن بين العمل التجاري والراحة الشخصية هو سر النجاح",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // تفاصيل المؤشرات الحيوية
                    VitalStatProgress(label = "الطاقة والنشاط ⚡", value = playerLife.energy, color = Color(0xFFFFA000))
                    Spacer(modifier = Modifier.height(10.dp))
                    VitalStatProgress(label = "الصحة البدنية ❤️", value = playerLife.health, color = Color(0xFFE53935))
                    Spacer(modifier = Modifier.height(10.dp))
                    VitalStatProgress(label = "السعادة والراحة النفسية 😊", value = playerLife.happiness, color = Color(0xFF43A047))
                }

                // المسكن الحالي
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Home, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text("المسكن الريفي الحالي", style = MaterialTheme.typography.labelSmall)
                            Text(
                                text = playerLife.housingLevel,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text("مصاريف الطعام اليومية: ${playerLife.dailyFoodCost} ريال", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        // القسم الأيسر: الأنشطة الشخصية
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxSize(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "الأنشطة اليومية والترفيه ☕",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                // 1. قيلولة
                LifeActionCard(
                    title = "أخذ قيلولة ريفية 😴",
                    desc = "استعادة +25 نقطة طاقة من خلال راحة قصيرة في الكوخ.",
                    costText = "مجاناً",
                    buttonText = "أخذ قيلولة",
                    isEnabled = playerLife.energy < 100,
                    onClick = { onPerformAction(LifeActionType.REST_NAP) },
                    testTag = "btn_action_nap"
                )

                // 2. وجبة صحية
                LifeActionCard(
                    title = "تناول وجبة ريفية مغذية 🥗",
                    desc = "تزيد الصحة (+15)، والطاقة (+15)، والسعادة (+10).",
                    costText = "20 ريال",
                    buttonText = "شراء وتناول الوجبة",
                    isEnabled = playerCash >= 20,
                    onClick = { onPerformAction(LifeActionType.HEALTHY_MEAL) },
                    testTag = "btn_action_meal"
                )

                // 3. جولة بالقرية
                LifeActionCard(
                    title = "نزهة بين حقول القرية 🌳",
                    desc = "تحسن المزاج وترفع السعادة (+20) مقابل استهلاك 10 نقاط طاقة.",
                    costText = "10 طاقة",
                    buttonText = "بدء النزهة",
                    isEnabled = playerLife.energy >= 10,
                    onClick = { onPerformAction(LifeActionType.VILLAGE_WALK) },
                    testTag = "btn_action_walk"
                )
            }
        }
    }
}

@Composable
fun VitalStatProgress(label: String, value: Int, color: Color) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
            Text("$value%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { value / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

@Composable
fun LifeActionCard(
    title: String,
    desc: String,
    costText: String,
    buttonText: String,
    isEnabled: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("التكلفة: $costText", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onClick,
                enabled = isEnabled,
                modifier = Modifier
                    .height(36.dp)
                    .testTag(testTag),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)
            ) {
                Text(buttonText, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
