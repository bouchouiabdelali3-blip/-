package com.example.game.model

/**
 * فترات اليوم في اللعبة
 */
enum class TimeOfDay(val titleAr: String, val icon: String) {
    MORNING("صباحاً", "☀️"),
    AFTERNOON("ظهراً", "🌤️"),
    EVENING("مساءً", "🌅"),
    NIGHT("ليلاً", "🌙")
}

/**
 * مرحلة القصة الحالية
 */
enum class StoryStep {
    PROLOGUE_CALL,         // المكالمة الهاتفية وإبلاغ الميراث
    INHERITANCE_ACCEPTED,  // استلام الميراث وتفقد المتجر القديم
    FIRST_DAY_ACTIVE,      // اليوم الأول في المتجر
    BUSINESS_EXPANDING     // مرحلة التطوير الحر
}

/**
 * الحوار السردي للقصة
 */
data class StoryDialogue(
    val speaker: String,
    val speakerRole: String,
    val message: String,
    val primaryButtonAr: String,
    val secondaryButtonAr: String? = null
)

/**
 * سجل أحداث اليوم
 */
data class GameLog(
    val day: Int,
    val timeAr: String,
    val text: String,
    val isPositive: Boolean = true
)

/**
 * التقرير المالي اليومي
 */
data class FinancialReport(
    val day: Int,
    val grossSales: Long,
    val stockPurchases: Long,
    val wagesPaid: Long,
    val loanInstallment: Long,
    val livingExpenses: Long,
    val netProfit: Long
)

/**
 * مشهد من مشاهد المقدمة السردية
 */
data class StoryScene(
    val id: Int,
    val sceneBadgeAr: String,
    val titleAr: String,
    val textAr: String,
    val imageResId: Int,
    val buttonTextAr: String = "التالي"
)

fun createDefaultStoryScenes(): List<StoryScene> {
    return listOf(
        StoryScene(
            id = 1,
            sceneBadgeAr = "المشهد ١ من ٥",
            titleAr = "حياة القرية الهادئة",
            textAr = "كنت أعيش حياة بسيطة وهادئة في الريف بين المزارع والحقول، راضياً بيومي وبساطة عيشي.",
            imageResId = com.example.R.drawable.bg_countryside
        ),
        StoryScene(
            id = 2,
            sceneBadgeAr = "المشهد ٢ من ٥",
            titleAr = "اتصال مفاجئ من المدينة",
            textAr = "كان لي عمٌ عزيز يسكن في المدينة الكبيرة. وفي يومٍ غير متوقع، رن هاتفي بمكالمة حزينة تخبرني بوفاته.",
            imageResId = com.example.R.drawable.story_phone_call
        ),
        StoryScene(
            id = 3,
            sceneBadgeAr = "المشهد ٣ من ٥",
            titleAr = "الوصية والميراث",
            textAr = "أوضح المتصل أن عمي ترك وصية رسمية مسجلة وسمّاني فيها وريثاً شرعياً له. حزمت حقيبتي وانطلقت إلى المدينة.",
            imageResId = com.example.R.drawable.story_travel_city
        ),
        StoryScene(
            id = 4,
            sceneBadgeAr = "المشهد ٤ من ٥",
            titleAr = "اكتشاف متجر العم",
            textAr = "وصلت واكتشفت ما تركه عمي: دكان خضار وفواكه قديم وصغير، مبلغ نقدي بسيط، ورفوف خشبية عتيقة ومعدات أساسية.",
            imageResId = com.example.R.drawable.story_old_store
        ),
        StoryScene(
            id = 5,
            sceneBadgeAr = "المشهد ٥ من ٥",
            titleAr = "العزيمة والبداية",
            textAr = "رغم بساطة المتجر وحالته القديمة، قررت ألا أستسلم. سأنظف المكان وأرتب الرفوف وأبدأ رحلتي في عالم التجارة والأعمال!",
            imageResId = com.example.R.drawable.story_determined
        )
    )
}
