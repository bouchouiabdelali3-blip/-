package com.example.game.model

/**
 * الحالة الشاملة للعبة (Business Life - حياة الأعمال)
 */
data class GameState(
    val day: Int = 1,
    val timeOfDay: TimeOfDay = TimeOfDay.MORNING,
    val cash: Long = 250L,             // مبلغ الميراث النقدي المتواضع
    val bankBalance: Long = 0L,        // رصيد البنك
    val activeLoan: Loan? = null,      // قرض بنكي نشط
    val store: Store = createInitialStore(),
    val inventory: List<InventoryItem> = createInitialInventory(),
    val employees: List<Employee> = createInitialEmployees(),
    val playerLife: PlayerLife = PlayerLife(),
    val storyStep: StoryStep = StoryStep.PROLOGUE_CALL,
    val activeDialogue: StoryDialogue? = createPrologueDialogue(),
    val dailyLogs: List<GameLog> = createInitialLogs(),
    val lastFinancialReport: FinancialReport? = null,
    val totalRevenueEarned: Long = 0L,
    val daysPlayed: Int = 1,
    val todaySales: Long = 0L,
    val todayProfit: Long = 0L,
    val todayCustomersServed: Int = 0
)

fun createInitialStore(): Store {
    return Store(
        id = "store_fruit_veg_old",
        nameAr = "دكان الخضار والفواكه القديم",
        locationAr = "أطراف القرية الريفية",
        reputation = 25,
        dailyFootTraffic = 15,
        equipments = listOf(
            StoreEquipment(
                id = "scale",
                nameAr = "ميزان قديم يدوي",
                descriptionAr = "ميزان ورثته عن عمك، دقيق نوعاً ما لكنه بطيء",
                level = 1,
                upgradeCost = 120L,
                customerBonusPercent = 15,
                iconEmoji = "⚖️"
            ),
            StoreEquipment(
                id = "shelves",
                nameAr = "صناديق خشبية متهالكة",
                descriptionAr = "صناديق بسيطة لعرض التفاح والبرتقال والخضروات",
                level = 1,
                upgradeCost = 180L,
                customerBonusPercent = 20,
                iconEmoji = "🪵"
            ),
            StoreEquipment(
                id = "cash_box",
                nameAr = "صندوق نقود معدني عتيق",
                descriptionAr = "صندوق حفظ النقود المعدنية والورقية القديم",
                level = 1,
                upgradeCost = 150L,
                customerBonusPercent = 10,
                iconEmoji = "🪙"
            )
        )
    )
}

fun createInitialInventory(): List<InventoryItem> {
    return listOf(
        InventoryItem(
            id = "potatoes",
            nameAr = "بطاطا",
            categoryAr = "خضروات",
            wholesalePrice = 2L,
            retailPrice = 4L,
            currentStock = 20,
            maxCapacity = 120,
            iconEmoji = "🥔",
            baseWholesalePrice = 2L,
            baseRetailPrice = 4L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "tomatoes",
            nameAr = "طماطم",
            categoryAr = "خضروات",
            wholesalePrice = 3L,
            retailPrice = 6L,
            currentStock = 20,
            maxCapacity = 100,
            iconEmoji = "🍅",
            baseWholesalePrice = 3L,
            baseRetailPrice = 6L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "onions",
            nameAr = "بصل",
            categoryAr = "خضروات",
            wholesalePrice = 2L,
            retailPrice = 4L,
            currentStock = 18,
            maxCapacity = 100,
            iconEmoji = "🧅",
            baseWholesalePrice = 2L,
            baseRetailPrice = 4L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "carrots",
            nameAr = "جزر",
            categoryAr = "خضروات",
            wholesalePrice = 3L,
            retailPrice = 5L,
            currentStock = 15,
            maxCapacity = 90,
            iconEmoji = "🥕",
            baseWholesalePrice = 3L,
            baseRetailPrice = 5L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "cucumbers",
            nameAr = "خيار",
            categoryAr = "خضروات",
            wholesalePrice = 3L,
            retailPrice = 5L,
            currentStock = 15,
            maxCapacity = 90,
            iconEmoji = "🥒",
            baseWholesalePrice = 3L,
            baseRetailPrice = 5L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "apples",
            nameAr = "تفاح",
            categoryAr = "فواكه",
            wholesalePrice = 5L,
            retailPrice = 9L,
            currentStock = 15,
            maxCapacity = 80,
            iconEmoji = "🍎",
            baseWholesalePrice = 5L,
            baseRetailPrice = 9L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "bananas",
            nameAr = "موز",
            categoryAr = "فواكه",
            wholesalePrice = 4L,
            retailPrice = 8L,
            currentStock = 12,
            maxCapacity = 70,
            iconEmoji = "🍌",
            baseWholesalePrice = 4L,
            baseRetailPrice = 8L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "oranges",
            nameAr = "برتقال",
            categoryAr = "فواكه",
            wholesalePrice = 4L,
            retailPrice = 7L,
            currentStock = 15,
            maxCapacity = 80,
            iconEmoji = "🍊",
            baseWholesalePrice = 4L,
            baseRetailPrice = 7L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "strawberries",
            nameAr = "فراولة",
            categoryAr = "فواكه",
            wholesalePrice = 7L,
            retailPrice = 13L,
            currentStock = 10,
            maxCapacity = 50,
            iconEmoji = "🍓",
            baseWholesalePrice = 7L,
            baseRetailPrice = 13L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        ),
        InventoryItem(
            id = "watermelons",
            nameAr = "بطيخ",
            categoryAr = "فواكه",
            wholesalePrice = 8L,
            retailPrice = 16L,
            currentStock = 8,
            maxCapacity = 40,
            iconEmoji = "🍉",
            baseWholesalePrice = 8L,
            baseRetailPrice = 16L,
            priceTrend = PriceTrend.STABLE,
            priceChangePercent = 0
        )
    )
}

fun createInitialEmployees(): List<Employee> {
    return listOf(
        Employee(
            id = "emp_1",
            nameAr = "سعيد القروي",
            role = EmployeeRole.CLEANER,
            dailyWage = 20L,
            efficiencyPercent = 70,
            isHired = false,
            avatarEmoji = "🧹"
        ),
        Employee(
            id = "emp_2",
            nameAr = "خالد البشوش",
            role = EmployeeRole.SALES_ASSISTANT,
            dailyWage = 35L,
            efficiencyPercent = 85,
            isHired = false,
            avatarEmoji = "👨‍💼"
        ),
        Employee(
            id = "emp_3",
            nameAr = "عمر الأمين",
            role = EmployeeRole.STOCK_KEEPER,
            dailyWage = 30L,
            efficiencyPercent = 80,
            isHired = false,
            avatarEmoji = "📦"
        )
    )
}

fun createPrologueDialogue(): StoryDialogue {
    return StoryDialogue(
        speaker = "المحامي سمير",
        speakerRole = "محامي العائلة",
        message = "السلام عليكم يا بني.. يؤسفني إبلاغك بوفاة عمك الحاج صالح رحمه الله. لقد أوصى لك بميراث متواضع: دكانه القديم لبيع الخضار والفواكه على مشارف القرية، مع مبلغ 250 ريال نقد ومعدات الدكان الأساسية. كان عمك يؤمن بأنك قادر على تنمية هذا المتجر وبناء مستقبل عظيم.",
        primaryButtonAr = "استلام الميراث وتفقد الدكان",
        secondaryButtonAr = "قراءة بنود الوصية"
    )
}

fun createInitialLogs(): List<GameLog> {
    return listOf(
        GameLog(
            day = 1,
            timeAr = "صباحاً",
            text = "تلقيت اتصالاً هاتفياً من المحامي سمير يعلن استلام ميراث العم صالح: دكان الخضار والفواكه ومبلغ 250 ريال.",
            isPositive = true
        )
    )
}
