package com.example.game.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.game.engine.GameScreen
import com.example.game.engine.LiveSaleResult
import com.example.game.model.FinancialReport
import com.example.game.model.InventoryItem
import com.example.game.model.Store
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * بيانات الزبون المتحرك في المتجر
 */
data class AnimatedCustomer(
    val id: Long,
    val nameAr: String,
    val avatarEmoji: String,
    val wantedItemEmoji: String,
    val isLeaving: Boolean = false,
    val purchaseTextAr: String? = null
)

/**
 * إشعار متحرك طافي (تحديثات الأموال والمخزون)
 */
data class FloatingAlert(
    val id: Long,
    val textAr: String,
    val isPositiveMoney: Boolean,
    val offsetX: Int,
    val offsetY: Int
)

@Composable
fun StoreScreen(
    store: Store,
    playerCash: Long,
    inventory: List<InventoryItem>,
    todaySales: Long,
    todayProfit: Long,
    todayCustomersServed: Int,
    lastReport: FinancialReport?,
    onNavigate: (GameScreen) -> Unit,
    onLiveCustomerSale: () -> LiveSaleResult?,
    modifier: Modifier = Modifier
) {
    val totalStock = remember(inventory) { inventory.sumOf { it.currentStock } }
    val totalCapacity = remember(inventory) { inventory.sumOf { it.maxCapacity } }

    val displaySales = if (todaySales > 0) todaySales else (lastReport?.grossSales ?: 0L)
    val displayProfit = if (todayProfit != 0L) todayProfit else (lastReport?.netProfit ?: 0L)
    val displayCustomers = if (todayCustomersServed > 0) todayCustomersServed else store.dailyFootTraffic

    // حالة الزبائن المتحركين
    var currentCustomer by remember { mutableStateOf<AnimatedCustomer?>(null) }
    val floatingAlerts = remember { mutableStateListOf<FloatingAlert>() }

    // مؤشر حركة المحل والاهتزاز الخفيف
    val infiniteTransition = rememberInfiniteTransition(label = "store_activity")
    val awningOffset by infiniteTransition.animateFloat(
        initialValue = -2f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "awning_breeze"
    )
    val openSignAlpha by infiniteTransition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sign_glow"
    )

    // تفاعل النقر على الدكان
    var tapScale by remember { mutableStateOf(1f) }
    val animatedScale by animateFloatAsState(
        targetValue = tapScale,
        animationSpec = tween(150),
        label = "tap_bounce"
    )

    // حلقة محاكاة الزبائن الحيّة لدكان الخضار والفواكه
    LaunchedEffect(store.isOpen, totalStock) {
        val customerAvatars = listOf("👨‍🌾", "👩‍💼", "👵", "👴", "🧑‍🦱", "👳‍♂️", "👧")
        val customerNames = listOf("أبو فهد", "أم أحمد", "سارة", "سالم", "أم فيصل", "عبدالله", "نورة")

        while (true) {
            delay(4800L)
            if (store.isOpen && totalStock > 0 && currentCustomer == null) {
                val availableItems = inventory.filter { it.currentStock > 0 }
                if (availableItems.isNotEmpty()) {
                    val randomItem = availableItems.random()
                    val randomAvatar = customerAvatars.random()
                    val randomName = customerNames.random()

                    // وصول الزبون إلى المتجر
                    currentCustomer = AnimatedCustomer(
                        id = System.currentTimeMillis(),
                        nameAr = randomName,
                        avatarEmoji = randomAvatar,
                        wantedItemEmoji = randomItem.iconEmoji
                    )

                    delay(1500L) // يقف الزبون أمام رفوف الخضار

                    // إتمام الشراء والتحديثات الطافية
                    val saleResult = onLiveCustomerSale()
                    if (saleResult != null) {
                        val alertId = System.currentTimeMillis()
                        floatingAlerts.add(
                            FloatingAlert(
                                id = alertId,
                                textAr = "+${saleResult.revenue} ريال 💵",
                                isPositiveMoney = true,
                                offsetX = Random.nextInt(-40, 40),
                                offsetY = 0
                            )
                        )
                        floatingAlerts.add(
                            FloatingAlert(
                                id = alertId + 1,
                                textAr = "-${saleResult.units} ${saleResult.itemNameAr} ${saleResult.itemEmoji}",
                                isPositiveMoney = false,
                                offsetX = Random.nextInt(-30, 50),
                                offsetY = -30
                            )
                        )

                        // الزبون يغادر حاملاً كيس المشتريات
                        currentCustomer = currentCustomer?.copy(
                            isLeaving = true,
                            purchaseTextAr = "شكراً لك! 🛍️"
                        )
                    }

                    delay(1800L)
                    currentCustomer = null
                }
            }
        }
    }

    // تنظيف التنبيهات الطافية تلقائياً
    LaunchedEffect(floatingAlerts.size) {
        if (floatingAlerts.isNotEmpty()) {
            delay(2000L)
            if (floatingAlerts.isNotEmpty()) {
                floatingAlerts.removeAt(0)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("screen_store"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. حول صورة المتجر: عرض المعلومات الست الأكثر أهمية فقط
        // (المال، المبيعات، الأرباح، المخزون، الزبائن، حالة المتجر)
        StoreMetricsBar(
            cash = playerCash,
            sales = displaySales,
            profit = displayProfit,
            currentStock = totalStock,
            maxCapacity = totalCapacity,
            customers = displayCustomers,
            isOpen = store.isOpen,
            hasStock = totalStock > 0
        )

        Spacer(modifier = Modifier.height(6.dp))

        // 2. المركز (CENTER): صورة توضيحية ثنائية الأبعاد كبيرة وجذابة لدكان الخضار والفواكه
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .border(2.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                .scale(animatedScale)
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {
                    tapScale = 1.015f
                    // تفاعل النقر السريع للترحيب بزبون أو إنعاش المتجر
                    if (store.isOpen && totalStock > 0 && currentCustomer == null) {
                        val sale = onLiveCustomerSale()
                        if (sale != null) {
                            floatingAlerts.add(
                                FloatingAlert(
                                    id = System.currentTimeMillis(),
                                    textAr = "+${sale.revenue} ريال 💵",
                                    isPositiveMoney = true,
                                    offsetX = 0,
                                    offsetY = -20
                                )
                            )
                        }
                    }
                }
                .testTag("center_store_illustration_stage"),
            contentAlignment = Alignment.Center
        ) {
            // صورة المتجر 2D الاحترافية في المركز
            Image(
                painter = painterResource(id = R.drawable.fruit_vegetable_shop_center),
                contentDescription = "دكان الخضار والفواكه",
                modifier = Modifier
                    .fillMaxSize()
                    .offset { IntOffset(0, awningOffset.roundToInt()) },
                contentScale = ContentScale.Crop
            )

            // طبقة تظليل خفيفة للتناغم البصري مع العناصر التفاعلية
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.15f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.40f)
                            )
                        )
                    )
            )

            // لافتة اسم المتجر والنشاط في زاوية المشهد
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("🏪", style = MaterialTheme.typography.labelLarge)
                    Column {
                        Text(
                            text = store.nameAr,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "المتجر الأول: نشاط بيع الخضار والفواكه الطازجة",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFFD54F)
                        )
                    }
                }
            }

            // لافتة حالة المحل المضيئة (مفتوح / مغلق)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .alpha(openSignAlpha)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (store.isOpen && totalStock > 0) Color(0xFF1B5E20).copy(alpha = 0.9f)
                        else Color(0xFFB71C1C).copy(alpha = 0.9f)
                    )
                    .border(
                        1.dp,
                        if (store.isOpen && totalStock > 0) Color(0xFF81C784) else Color(0xFFEF9A9A),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (store.isOpen && totalStock > 0) Color(0xFF00E676) else Color(0xFFFF5252))
                    )
                    Text(
                        text = if (store.isOpen && totalStock > 0) "المتجر مفتوح ومزدهر" else if (totalStock == 0) "المخزون نفد!" else "المتجر مغلق",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // حركة بائع المتجر (العم صالح أو المساعد) في الواجهة
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 18.dp, bottom = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.60f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("🧑‍🌾", fontSize = 22.sp)
                    Column {
                        Text("البائع جاهز للخدمة 👋", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("انقر على الدكان لخدمة الزبائن", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB0BEC5))
                    }
                }
            }

            // حركة الزبائن: الدخول والشراء والمغادرة مع حقيبة المشتريات
            currentCustomer?.let { customer ->
                AnimatedCustomerView(
                    customer = customer,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                )
            }

            // التحديثات المالية وتحديثات المخزون الطافية (Floating Money and Inventory Updates)
            floatingAlerts.forEach { alert ->
                FloatingAlertBadge(
                    alert = alert,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // إرجاع مقياس النقر
        LaunchedEffect(tapScale) {
            if (tapScale != 1f) {
                delay(120L)
                tapScale = 1f
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. أزرار اللمس الواضحة الخمسة (تفتح كل منها شاشتها المنفصلة دون ازدحام):
        // "شراء البضائع" - "المخزون" - "الموظفون" - "تطوير المتجر" - "التقارير"
        StoreActionButtonsBar(
            onOpenBuyGoods = { onNavigate(GameScreen.BUY_GOODS) },
            onOpenInventory = { onNavigate(GameScreen.INVENTORY) },
            onOpenEmployees = { onNavigate(GameScreen.EMPLOYEES) },
            onOpenStoreUpgrade = { onNavigate(GameScreen.STORE_UPGRADE) },
            onOpenReports = { onNavigate(GameScreen.REPORTS) }
        )
    }
}

/**
 * شريط المعلومات الست الأكثر أهمية حول صورة المتجر
 */
@Composable
private fun StoreMetricsBar(
    cash: Long,
    sales: Long,
    profit: Long,
    currentStock: Int,
    maxCapacity: Int,
    customers: Int,
    isOpen: Boolean,
    hasStock: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. المال
            MetricChip(
                iconEmoji = "💵",
                label = "المال",
                value = "$cash ريال",
                color = MaterialTheme.colorScheme.primary,
                testTag = "metric_cash"
            )

            // 2. المبيعات
            MetricChip(
                iconEmoji = "📈",
                label = "المبيعات",
                value = "$sales ريال",
                color = MaterialTheme.colorScheme.secondary,
                testTag = "metric_sales"
            )

            // 3. الأرباح
            MetricChip(
                iconEmoji = "💰",
                label = "الأرباح",
                value = if (profit >= 0) "+$profit ريال" else "$profit ريال",
                color = if (profit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828),
                testTag = "metric_profit"
            )

            // 4. المخزون
            MetricChip(
                iconEmoji = "📦",
                label = "المخزون",
                value = "$currentStock/$maxCapacity",
                color = if (currentStock < 20) Color(0xFFE65100) else Color(0xFF455A64),
                testTag = "metric_inventory"
            )

            // 5. الزبائن
            MetricChip(
                iconEmoji = "👥",
                label = "الزبائن",
                value = "$customers زبون",
                color = Color(0xFF6A1B9A),
                testTag = "metric_customers"
            )

            // 6. حالة المتجر
            val statusText = if (!isOpen) "مغلق مؤقتاً 🔴" else if (!hasStock) "نفاد المخزون ⚠️" else "مفتوح 🟢"
            val statusColor = if (!isOpen) Color(0xFFC62828) else if (!hasStock) Color(0xFFE65100) else Color(0xFF2E7D32)

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(statusColor.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("metric_store_status")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("حالة المتجر", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricChip(
    iconEmoji: String,
    label: String,
    value: String,
    color: Color,
    testTag: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        modifier = Modifier.testTag(testTag)
    ) {
        Text(iconEmoji, fontSize = 16.sp)
        Column {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

/**
 * حركة الزبون في المتجر (دخول، تفكير في المنتج، ومغادرة مع كيس المشتريات)
 */
@Composable
private fun AnimatedCustomerView(
    customer: AnimatedCustomer,
    modifier: Modifier = Modifier
) {
    val targetOffsetX = if (customer.isLeaving) -90.dp else 40.dp
    val animatedOffsetX by animateFloatAsState(
        targetValue = targetOffsetX.value,
        animationSpec = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
        label = "customer_movement"
    )

    Box(
        modifier = modifier
            .offset { IntOffset(animatedOffsetX.roundToInt(), 0) }
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.75f))
            .border(1.dp, Color(0xFFFFD54F), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("customer_animated_view")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = if (customer.isLeaving) "${customer.avatarEmoji}🛍️" else customer.avatarEmoji,
                fontSize = 22.sp
            )
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = customer.nameAr,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (customer.isLeaving) "اشترى بنجاح ⭐" else "يطلب بضاعة",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (customer.isLeaving) Color(0xFF81C784) else Color(0xFFFFD54F)
                    )
                }
                Text(
                    text = if (customer.isLeaving) customer.purchaseTextAr ?: "شكراً لك!" else "يريد شراء ${customer.wantedItemEmoji}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * شارة التحديثات الطافية (تحديثات الأموال والمخزون)
 */
@Composable
private fun FloatingAlertBadge(
    alert: FloatingAlert,
    modifier: Modifier = Modifier
) {
    var animOffset by remember { mutableStateOf(0f) }
    var animAlpha by remember { mutableStateOf(1f) }

    LaunchedEffect(Unit) {
        animOffset = -45f
        animAlpha = 0f
    }

    val animatedOffsetY by animateFloatAsState(
        targetValue = animOffset,
        animationSpec = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
        label = "alert_float"
    )
    val animatedAlpha by animateFloatAsState(
        targetValue = animAlpha,
        animationSpec = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
        label = "alert_fade"
    )

    Box(
        modifier = modifier
            .offset { IntOffset(alert.offsetX, (alert.offsetY + animatedOffsetY).roundToInt()) }
            .alpha(animatedAlpha)
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (alert.isPositiveMoney) Color(0xFF1B5E20).copy(alpha = 0.9f)
                else Color(0xFFE65100).copy(alpha = 0.9f)
            )
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = alert.textAr,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

/**
 * أزرار اللمس الخمسة الواضحة في أسفل الشاشة
 */
@Composable
private fun StoreActionButtonsBar(
    onOpenBuyGoods: () -> Unit,
    onOpenInventory: () -> Unit,
    onOpenEmployees: () -> Unit,
    onOpenStoreUpgrade: () -> Unit,
    onOpenReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 1. شراء البضائع
        StoreActionButton(
            titleAr = "شراء البضائع",
            icon = Icons.Default.ShoppingCart,
            backgroundColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            testTag = "btn_store_buy_goods",
            onClick = onOpenBuyGoods,
            modifier = Modifier.weight(1f)
        )

        // 2. المخزون
        StoreActionButton(
            titleAr = "المخزون",
            icon = Icons.Default.Inventory2,
            backgroundColor = MaterialTheme.colorScheme.secondary,
            contentColor = MaterialTheme.colorScheme.onSecondary,
            testTag = "btn_store_inventory",
            onClick = onOpenInventory,
            modifier = Modifier.weight(1f)
        )

        // 3. الموظفون
        StoreActionButton(
            titleAr = "الموظفون",
            icon = Icons.Default.Group,
            backgroundColor = MaterialTheme.colorScheme.tertiary,
            contentColor = MaterialTheme.colorScheme.onTertiary,
            testTag = "btn_store_employees",
            onClick = onOpenEmployees,
            modifier = Modifier.weight(1f)
        )

        // 4. تطوير المتجر
        StoreActionButton(
            titleAr = "تطوير المتجر",
            icon = Icons.Default.Build,
            backgroundColor = Color(0xFF00796B),
            contentColor = Color.White,
            testTag = "btn_store_upgrades",
            onClick = onOpenStoreUpgrade,
            modifier = Modifier.weight(1f)
        )

        // 5. التقارير
        StoreActionButton(
            titleAr = "التقارير",
            icon = Icons.Default.Assessment,
            backgroundColor = Color(0xFF455A64),
            contentColor = Color.White,
            testTag = "btn_store_reports",
            onClick = onOpenReports,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StoreActionButton(
    titleAr: String,
    icon: ImageVector,
    backgroundColor: Color,
    contentColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxHeight()
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = titleAr,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = titleAr,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}
