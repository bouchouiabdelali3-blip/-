package com.example.game.data

import com.example.game.model.GameState
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class GameRepository(private val gameSaveDao: GameSaveDao) {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(GameState::class.java)

    /**
     * تدفق يراقب وجود حفظ سابق
     */
    val hasSavedGameFlow: Flow<Boolean> = gameSaveDao.getGameSaveFlow().map { it != null }

    /**
     * قراءة الحفظ واسترجاع حالة اللعبة
     */
    suspend fun loadSavedGameState(): GameState? = withContext(Dispatchers.IO) {
        try {
            val entity = gameSaveDao.getGameSaveOnce() ?: return@withContext null
            adapter.fromJson(entity.jsonState)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * حفظ حالة اللعبة الحالية في قاعدة بيانات Room
     */
    suspend fun saveGameState(state: GameState) = withContext(Dispatchers.IO) {
        try {
            val json = adapter.toJson(state)
            val entity = GameSaveEntity(
                id = 1,
                day = state.day,
                cash = state.cash,
                storeName = state.store.nameAr,
                jsonState = json,
                savedAtTimestamp = System.currentTimeMillis()
            )
            gameSaveDao.insertOrUpdateSave(entity)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * حذف الحفظ لبدء لعبة جديدة
     */
    suspend fun clearSave() = withContext(Dispatchers.IO) {
        gameSaveDao.deleteSave()
    }
}
