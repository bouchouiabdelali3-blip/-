package com.example.game.ui.components

import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.game.engine.GameScreen

data class NavRailDestination(
    val screen: GameScreen,
    val titleAr: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun GameNavRail(
    currentScreen: GameScreen,
    onSelectScreen: (GameScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val destinations = listOf(
        NavRailDestination(GameScreen.DASHBOARD, "الرئيسية", Icons.Default.Dashboard, "nav_dashboard"),
        NavRailDestination(GameScreen.STORE, "المتجر", Icons.Default.Storefront, "nav_store"),
        NavRailDestination(GameScreen.INVENTORY, "المخزون", Icons.Default.Inventory2, "nav_inventory"),
        NavRailDestination(GameScreen.EMPLOYEES, "الموظفون", Icons.Default.Group, "nav_employees"),
        NavRailDestination(GameScreen.BANK, "البنك", Icons.Default.AccountBalance, "nav_bank"),
        NavRailDestination(GameScreen.PERSONAL_LIFE, "حياتي", Icons.Default.Favorite, "nav_personal_life"),
        NavRailDestination(GameScreen.LOGS, "السجل", Icons.AutoMirrored.Filled.List, "nav_logs")
    )

    NavigationRail(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp)
            .testTag("game_navigation_rail"),
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        header = {
            NavigationRailItem(
                selected = false,
                onClick = { onSelectScreen(GameScreen.MAIN_MENU) },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "القائمة الرئيسية",
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = { Text("القائمة", style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier
                    .padding(top = 4.dp, bottom = 4.dp)
                    .testTag("nav_menu_home")
            )
        }
    ) {
        val scrollState = rememberScrollState()
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.verticalScroll(scrollState)
        ) {
            destinations.forEach { item ->
                val isSelected = currentScreen == item.screen ||
                    (item.screen == GameScreen.STORE && (
                        currentScreen == GameScreen.BUY_GOODS ||
                        currentScreen == GameScreen.STORE_UPGRADE ||
                        currentScreen == GameScreen.REPORTS
                    ))
                NavigationRailItem(
                    selected = isSelected,
                    onClick = { onSelectScreen(item.screen) },
                    icon = {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.titleAr,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text(item.titleAr, style = MaterialTheme.typography.labelSmall) },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag(item.testTag)
                )
            }
        }
    }
}
