package com.example.game.model

/**
 * وظيفة موظف
 */
enum class EmployeeRole(val titleAr: String, val descAr: String) {
    CLEANER("عامل نظافة وترتيب", "يحافظ على نظافة المتجر وجودة الخضار والفواكه"),
    SALES_ASSISTANT("بائع ومساعد", "يزيد من سرعة خدمة الزبائن ورفع المبيعات"),
    STOCK_KEEPER("مسؤول مخازن", "يقلل من تلف البضائع ويسهل ترتيب الصناديق")
}

/**
 * بيانات الموظف
 */
data class Employee(
    val id: String,
    val nameAr: String,
    val role: EmployeeRole,
    val dailyWage: Long, // الأجر اليومي
    val efficiencyPercent: Int, // كفاءة العمل
    val isHired: Boolean = false,
    val avatarEmoji: String = "👨‍🌾"
)

/**
 * بيانات القرض البنكي
 */
data class Loan(
    val id: String,
    val titleAr: String,
    val principalAmount: Long, // المبلغ الأصلي
    val totalRepayment: Long,   // إجمالي المبلغ الواجب سداده
    val remainingAmount: Long,  // المبلغ المتبقي
    val dailyInstallment: Long, // القسط اليومي
    val totalDays: Int,         // مدة السداد بالأيام
    val daysRemaining: Int      // الأيام المتبقية
)

/**
 * بيانات الحياة الشخصية للاعب
 */
data class PlayerLife(
    val nameAr: String = "اللاعب",
    val energy: Int = 100,      // الطاقة (0 - 100)
    val health: Int = 100,      // الصحة (0 - 100)
    val happiness: Int = 85,    // السعادة (0 - 100)
    val housingLevel: String = "كوخ ريفي متواضع",
    val dailyFoodCost: Long = 15 // تكلفة الطعام اليومية الأساسية
)
