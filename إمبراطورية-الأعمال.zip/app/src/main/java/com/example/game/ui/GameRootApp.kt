package com.example.game.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.engine.GameScreen
import com.example.game.engine.GameViewModel
import com.example.game.ui.components.DailySummaryDialog
import com.example.game.ui.components.GameNavRail
import com.example.game.ui.components.GameTopBar
import com.example.game.ui.components.SettingsDialog
import com.example.game.ui.components.StoryDialog
import com.example.game.ui.screens.BankScreen
import com.example.game.ui.screens.BuyGoodsScreen
import com.example.game.ui.screens.DashboardScreen
import com.example.game.ui.screens.EmployeesScreen
import com.example.game.ui.screens.InventoryScreen
import com.example.game.ui.screens.LogsScreen
import com.example.game.ui.screens.MainMenuScreen
import com.example.game.ui.screens.PersonalLifeScreen
import com.example.game.ui.screens.ReportsScreen
import com.example.game.ui.screens.StoreScreen
import com.example.game.ui.screens.StoreUpgradeScreen
import com.example.game.ui.screens.StoryIntroScreen

@Composable
fun GameRootApp(
    viewModel: GameViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    // إظهار الرسائل التنبيهية السريعة
    LaunchedEffect(uiState.toastMessageAr) {
        uiState.toastMessageAr?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.clearToast()
        }
    }

    // إجبار واجهة اللعبة بالكامل على استخدام تخطيط RTL العربي
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = Modifier.fillMaxSize()
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (uiState.currentScreen == GameScreen.MAIN_MENU) {
                    MainMenuScreen(
                        hasSavedGame = uiState.hasSavedGame,
                        onStartNewGame = { viewModel.startNewGame() },
                        onContinueGame = { viewModel.continueSavedGame() },
                        onPlayStoryIntro = { viewModel.playStoryIntro() },
                        onOpenSettings = { viewModel.toggleSettingsDialog(true) }
                    )
                } else if (uiState.currentScreen == GameScreen.STORY_INTRO) {
                    // شاشة مقدمة القصة والمشاهد السينمائية
                    StoryIntroScreen(
                        onFinishStoryIntro = { viewModel.completeStoryIntro() }
                    )
                } else {
                    // واجهة اللعبة الأفقية مع شريط الملاحة وشريط الحالة العلوي
                    Column(modifier = Modifier.fillMaxSize()) {
                        GameTopBar(
                            gameState = uiState.gameState,
                            onSaveGame = { viewModel.saveGame() },
                            onEndDay = { viewModel.endDayAndSimulate() }
                        )

                        Row(modifier = Modifier.fillMaxSize()) {
                            GameNavRail(
                                currentScreen = uiState.currentScreen,
                                onSelectScreen = { screen -> viewModel.navigateTo(screen) }
                            )

                            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                                AnimatedContent(
                                    targetState = uiState.currentScreen,
                                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                                    label = "game_screen_transition"
                                ) { targetScreen ->
                                    when (targetScreen) {
                                        GameScreen.DASHBOARD -> DashboardScreen(
                                            gameState = uiState.gameState,
                                            onNavigate = { screen -> viewModel.navigateTo(screen) },
                                            onEndDay = { viewModel.endDayAndSimulate() },
                                            onQuickNap = {
                                                viewModel.performLifeAction(com.example.game.engine.LifeActionType.REST_NAP)
                                            }
                                        )
                                        GameScreen.STORE -> StoreScreen(
                                            store = uiState.gameState.store,
                                            playerCash = uiState.gameState.cash,
                                            inventory = uiState.gameState.inventory,
                                            todaySales = uiState.gameState.todaySales,
                                            todayProfit = uiState.gameState.todayProfit,
                                            todayCustomersServed = uiState.gameState.todayCustomersServed,
                                            lastReport = uiState.gameState.lastFinancialReport,
                                            onNavigate = { screen -> viewModel.navigateTo(screen) },
                                            onLiveCustomerSale = { viewModel.processLiveCustomerSale() }
                                        )
                                        GameScreen.BUY_GOODS -> BuyGoodsScreen(
                                            inventory = uiState.gameState.inventory,
                                            playerCash = uiState.gameState.cash,
                                            onBuyStock = { itemId, qty -> viewModel.buyInventoryStock(itemId, qty) },
                                            onBuyMultipleItems = { purchases -> viewModel.buyMultipleItems(purchases) },
                                            onBackToStore = { viewModel.navigateTo(GameScreen.STORE) }
                                        )
                                        GameScreen.INVENTORY -> InventoryScreen(
                                            inventory = uiState.gameState.inventory,
                                            playerCash = uiState.gameState.cash,
                                            onBuyStock = { itemId, qty -> viewModel.buyInventoryStock(itemId, qty) },
                                            onBackToStore = { viewModel.navigateTo(GameScreen.STORE) }
                                        )
                                        GameScreen.EMPLOYEES -> EmployeesScreen(
                                            employees = uiState.gameState.employees,
                                            onHire = { empId -> viewModel.hireEmployee(empId) },
                                            onFire = { empId -> viewModel.fireEmployee(empId) },
                                            onBackToStore = { viewModel.navigateTo(GameScreen.STORE) }
                                        )
                                        GameScreen.STORE_UPGRADE -> StoreUpgradeScreen(
                                            store = uiState.gameState.store,
                                            playerCash = uiState.gameState.cash,
                                            onUpgradeEquipment = { eqId -> viewModel.upgradeEquipment(eqId) },
                                            onBackToStore = { viewModel.navigateTo(GameScreen.STORE) }
                                        )
                                        GameScreen.REPORTS -> ReportsScreen(
                                            currentDay = uiState.gameState.day,
                                            lastReport = uiState.gameState.lastFinancialReport,
                                            todaySales = uiState.gameState.todaySales,
                                            todayProfit = uiState.gameState.todayProfit,
                                            todayCustomersServed = uiState.gameState.todayCustomersServed,
                                            logs = uiState.gameState.dailyLogs,
                                            onBackToStore = { viewModel.navigateTo(GameScreen.STORE) }
                                        )
                                        GameScreen.BANK -> BankScreen(
                                            playerCash = uiState.gameState.cash,
                                            bankBalance = uiState.gameState.bankBalance,
                                            activeLoan = uiState.gameState.activeLoan,
                                            onDeposit = { amt -> viewModel.depositMoney(amt) },
                                            onWithdraw = { amt -> viewModel.withdrawMoney(amt) },
                                            onTakeLoan = { principal, days -> viewModel.takeLoan(principal, days) },
                                            onRepayLoanFull = { viewModel.repayLoanFull() }
                                        )
                                        GameScreen.PERSONAL_LIFE -> PersonalLifeScreen(
                                            playerLife = uiState.gameState.playerLife,
                                            playerCash = uiState.gameState.cash,
                                            onPerformAction = { action -> viewModel.performLifeAction(action) }
                                        )
                                        GameScreen.LOGS -> LogsScreen(
                                            logs = uiState.gameState.dailyLogs
                                        )
                                        GameScreen.MAIN_MENU,
                                        GameScreen.STORY_INTRO -> { /* يتم معالجتها كشاشات كاملة */ }
                                    }
                                }
                            }
                        }
                    }
                }

                // الحوارات المنبثقة للقصة والتقرير والإعدادات
                uiState.gameState.activeDialogue?.let { dialogue ->
                    StoryDialog(
                        dialogue = dialogue,
                        onChoice = { choice -> viewModel.onDialogueChoice(choice) }
                    )
                }

                if (uiState.showDailySummary && uiState.gameState.lastFinancialReport != null) {
                    DailySummaryDialog(
                        report = uiState.gameState.lastFinancialReport!!,
                        onDismiss = { viewModel.dismissDailySummary() }
                    )
                }

                if (uiState.showSettingsDialog) {
                    SettingsDialog(
                        onDismiss = { viewModel.toggleSettingsDialog(false) },
                        onResetSave = { viewModel.resetGame() }
                    )
                }
            }
        }
    }
}
