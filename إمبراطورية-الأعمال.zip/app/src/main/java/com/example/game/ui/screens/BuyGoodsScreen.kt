package com.example.game.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.model.InventoryItem
import com.example.game.model.PriceTrend
import kotlinx.coroutines.delay

/**
 * شاشة شراء البضائع لدكان الخضار والفواكه الأول (سوق الجملة)
 * واجهة باللغة العربية بالكامل وبنظام RTL ومصممة للوضع الأفقي
 */
@Composable
fun BuyGoodsScreen(
    inventory: List<InventoryItem>,
    playerCash: Long,
    onBuyStock: (String, Int) -> Unit = { _, _ -> },
    onBuyMultipleItems: ((Map<String, Int>) -> Boolean)? = null,
    onBackToStore: () -> Unit,
    modifier: Modifier = Modifier
) {
    // فرض الاتجاه من اليمين لليسار (RTL) لجميع عناصر الشاشة
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        // حالة الكميات المحددة لكل صنف (itemId -> quantity)
        val selectedQuantities = remember { mutableStateMapOf<String, Int>() }

        // حساب الإجماليات
        val totalQuantity = selectedQuantities.values.sum()
        val totalCost = selectedQuantities.entries.sumOf { (id, qty) ->
            val itm = inventory.find { it.id == id }
            (itm?.wholesalePrice ?: 0L) * qty
        }
        val remainingCash = playerCash - totalCost

        // حالة الرسوم المتحركة للتأكيد بعد الشراء
        var showConfirmationAnimation by remember { mutableStateOf(false) }
        var lastPurchasedUnits by remember { mutableIntStateOf(0) }
        var lastPurchasedCost by remember { mutableLongStateOf(0L) }

        // إغلاق نافذة التأكيد تلقائياً بعد ثانيتين
        if (showConfirmationAnimation) {
            LaunchedEffect(showConfirmationAnimation) {
                delay(2200)
                showConfirmationAnimation = false
            }
        }

        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .testTag("screen_buy_goods")
        ) {
            // تقسيم الشاشة أفقياً: شبكة المنتجات في الجانب الأكبر، وبطاقة ملخص الشراء الثابتة في الجانب الآخر
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                // 1. مساحة شبكة المنتجات (الجهة اليمنى في RTL)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    // شريط العنوان العلوي وزر العودة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onBackToStore,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_back_to_store_from_buy")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "العودة للمتجر",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "العودة للمتجر",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Column {
                                Text(
                                    text = "سوق الجملة — توريد دكان الخضار والفواكه 🥕🍎",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "اختر كميات الصناديق التي ترغب بشرائها لملء رفوف دكانك",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // رصيد اللاعب الحالي
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "رصيدك الحالي:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "$playerCash ريال 💵",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // شبكة بطاقات المنتجات الصغيرة الجذابة (المنتجات العشرة المطلوبة)
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 150.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentPadding = PaddingValues(bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(inventory, key = { it.id }) { item ->
                            val currentSelected = selectedQuantities[item.id] ?: 0
                            val remainingCapacity = (item.maxCapacity - item.currentStock - currentSelected).coerceAtLeast(0)

                            SmallProductCard(
                                item = item,
                                selectedQuantity = currentSelected,
                                canAddMore = remainingCapacity > 0,
                                onIncrease = {
                                    if (remainingCapacity > 0) {
                                        selectedQuantities[item.id] = currentSelected + 1
                                    }
                                },
                                onDecrease = {
                                    if (currentSelected > 0) {
                                        val next = currentSelected - 1
                                        if (next == 0) {
                                            selectedQuantities.remove(item.id)
                                        } else {
                                            selectedQuantities[item.id] = next
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("card_product_${item.id}")
                            )
                        }
                    }
                }

                // 2. بطاقة ملخص الشراء الثابتة والأزرار الرئيسية
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .width(260.dp)
                        .fillMaxHeight()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            // عنوان بطاقة الملخص
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingCart,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "ملخص الشراء",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (totalQuantity > 0) {
                                    IconButton(
                                        onClick = { selectedQuantities.clear() },
                                        modifier = Modifier.size(28.dp),
                                        colors = IconButtonDefaults.iconButtonColors(
                                            contentColor = MaterialTheme.colorScheme.error
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteSweep,
                                            contentDescription = "إفراغ السلة",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // 1. الكمية الإجمالية (المطلوبة حرفياً في التوجيهات)
                            SummaryRow(
                                label = "الكمية الإجمالية",
                                value = if (totalQuantity > 0) "$totalQuantity وحدة" else "0 وحدة",
                                isBold = true,
                                valueColor = if (totalQuantity > 0) MaterialTheme.colorScheme.primary else Color.Gray
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // 2. تكلفة الشراء (المطلوبة حرفياً في التوجيهات)
                            SummaryRow(
                                label = "تكلفة الشراء",
                                value = "$totalCost ريال",
                                isBold = true,
                                valueColor = if (totalCost > 0) Color(0xFFE65100) else Color.Gray
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // 3. المال المتبقي (المطلوبة حرفياً في التوجيهات)
                            SummaryRow(
                                label = "المال المتبقي",
                                value = "$remainingCash ريال",
                                isBold = true,
                                valueColor = if (remainingCash >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // تنبيه في حال تجاوز الميزانية
                            if (remainingCash < 0) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = "⚠️ المال المتوفر لا يكفي! يرجى تقليل الكميات.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // شارة الأسعار الديناميكية الذكية
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                    .padding(8.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = "💡 نظام الأسعار الديناميكية:",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 10.sp
                                    )
                                    Text(
                                        text = "تتغير أسعار الجملة يومياً بناءً على مواسم الحصاد وحركة سوق الجملة في الريف.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 9.sp,
                                        lineHeight = 12.sp
                                    )
                                }
                            }
                        }

                        // زر الشراء الواضح والبارز (المطلوب حرفياً: "شراء")
                        val isBuyEnabled = totalQuantity > 0 && remainingCash >= 0

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = {
                                    if (isBuyEnabled) {
                                        val itemsToBuy = selectedQuantities.toMap()
                                        lastPurchasedUnits = totalQuantity
                                        lastPurchasedCost = totalCost

                                        val success = if (onBuyMultipleItems != null) {
                                            onBuyMultipleItems(itemsToBuy)
                                        } else {
                                            // آلية بديلة في حال تمرير دالة الشراء الفردي
                                            itemsToBuy.forEach { (id, q) -> onBuyStock(id, q) }
                                            true
                                        }

                                        if (success) {
                                            selectedQuantities.clear()
                                            showConfirmationAnimation = true
                                        }
                                    }
                                },
                                enabled = isBuyEnabled,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("btn_confirm_purchase"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2E7D32),
                                    disabledContainerColor = Color.LightGray
                                )
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingCart,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = if (totalCost > 0) "شراء ($totalCost ريال)" else "شراء",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            if (totalQuantity > 0) {
                                OutlinedButton(
                                    onClick = { selectedQuantities.clear() },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(34.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = "إلغاء التحديد",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // نافذة الرسوم المتحركة للتأكيد بعد إتمام الشراء بنجاح
            AnimatedVisibility(
                visible = showConfirmationAnimation,
                enter = fadeIn() + scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy)),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                PurchaseConfirmationOverlay(
                    unitsPurchased = lastPurchasedUnits,
                    costDeducted = lastPurchasedCost,
                    remainingCash = playerCash,
                    onDismiss = { showConfirmationAnimation = false }
                )
            }
        }
    }
}

/**
 * بطاقة صغيرة وجذابة لعرض صنف الخضار أو الفاكهة
 * تحتوي على:
 * - رسم توضيحي مصغر للمنتج
 * - اسم المنتج بالعربية (المطلوبة نصاً: بطاطا، طماطم، بصل، جزر، خيار، تفاح، موز، برتقال، فراولة، بطيخ)
 * - سعر الشراء
 * - المخزون الحالي
 * - زر زيادة الكمية (+)
 * - زر إنقاص الكمية (-)
 */
@Composable
fun SmallProductCard(
    item: InventoryItem,
    selectedQuantity: Int,
    canAddMore: Boolean,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = selectedQuantity > 0
    val cardBorderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
    val cardBgColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp),
        modifier = modifier
            .border(
                width = if (isSelected) 1.8.dp else 1.dp,
                color = cardBorderColor,
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // شارة اتجاه السعر الديناميكي ورسم المنتج
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                // رسم المنتج المصغر
                ProductIllustration(
                    itemId = item.id,
                    nameAr = item.nameAr,
                    iconEmoji = item.iconEmoji,
                    modifier = Modifier.size(46.dp)
                )

                // شارة مؤشر اتجاه السعر في زاوية الرسم
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (item.priceTrend) {
                                PriceTrend.DISCOUNT -> Color(0xFFE8F5E9)
                                PriceTrend.FALLING -> Color(0xFFE3F2FD)
                                PriceTrend.RISING -> Color(0xFFFFEBEE)
                                PriceTrend.STABLE -> Color(0xFFF5F5F5)
                            }
                        )
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.priceTrend.symbol,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // مؤشر إذا كان هذا الصنف محدداً
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .size(18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$selectedQuantity",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // اسم المنتج باللغة العربية
            Text(
                text = item.nameAr,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // سعر الشراء
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "سعر الشراء:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
                Text(
                    text = "${item.wholesalePrice} ريال",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 11.sp
                )
            }

            // المخزون الحالي
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "المخزون:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
                Text(
                    text = "${item.currentStock}/${item.maxCapacity}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Medium,
                    fontSize = 10.sp
                )
            }

            // شريط السعة التخزينية
            LinearProgressIndicator(
                progress = { (item.currentStock.toFloat() / item.maxCapacity).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (item.currentStock < item.maxCapacity * 0.25f) Color(0xFFE65100) else Color(0xFF2E7D32),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(2.dp))

            // أزرار التحكم بالكمية المطلوبة: زر الزيادة (+) وزر الإنقاص (-)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // زر إنقاص الكمية (-)
                IconButton(
                    onClick = onDecrease,
                    enabled = selectedQuantity > 0,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("btn_decrease_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "إنقاص كمية ${item.nameAr}",
                        modifier = Modifier.size(16.dp),
                        tint = if (selectedQuantity > 0) MaterialTheme.colorScheme.error else Color.LightGray
                    )
                }

                // الكمية المحددة للشراء
                Text(
                    text = "$selectedQuantity",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )

                // زر زيادة الكمية (+)
                IconButton(
                    onClick = onIncrease,
                    enabled = canAddMore,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("btn_increase_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "زيادة كمية ${item.nameAr}",
                        modifier = Modifier.size(16.dp),
                        tint = if (canAddMore) MaterialTheme.colorScheme.primary else Color.LightGray
                    )
                }
            }
        }
    }
}

/**
 * رسم توضيحي مصغر ذو ألوان وتدرجات خاصة لكل صنف خضار وفاكهة
 */
@Composable
fun ProductIllustration(
    itemId: String,
    nameAr: String,
    iconEmoji: String,
    modifier: Modifier = Modifier
) {
    val gradientColors = when (itemId) {
        "potatoes" -> listOf(Color(0xFF8D6E63), Color(0xFF5D4037))
        "tomatoes" -> listOf(Color(0xFFEF5350), Color(0xFFC62828))
        "onions" -> listOf(Color(0xFFAB47BC), Color(0xFF6A1B9A))
        "carrots" -> listOf(Color(0xFFFFA726), Color(0xFFE65100))
        "cucumbers" -> listOf(Color(0xFF66BB6A), Color(0xFF2E7D32))
        "apples" -> listOf(Color(0xFFE53935), Color(0xFFB71C1C))
        "bananas" -> listOf(Color(0xFFFFEE58), Color(0xFFF57F17))
        "oranges" -> listOf(Color(0xFFFF9800), Color(0xFFE65100))
        "strawberries" -> listOf(Color(0xFFEC407A), Color(0xFFAD1457))
        "watermelons" -> listOf(Color(0xFF43A047), Color(0xFF1B5E20))
        else -> listOf(Color(0xFF78909C), Color(0xFF37474F))
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Brush.radialGradient(colors = gradientColors))
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = iconEmoji,
            fontSize = 22.sp,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * سطر عرض ملخص مالي
 */
@Composable
private fun SummaryRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = Color.Unspecified
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.SemiBold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = valueColor
        )
    }
}

/**
 * نافذة ورسوم متحركة مصغرة لتأكيد الشراء
 * تظهر بعد إتمام العملية مع أيقونة تفاعلية وتفاصيل البضائع المضافة ورصيد المال المتبقي
 */
@Composable
fun PurchaseConfirmationOverlay(
    unitsPurchased: Int,
    costDeducted: Long,
    remainingCash: Long,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .width(320.dp)
                .padding(8.dp)
                .testTag("dialog_purchase_confirmation")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // أيقونة التأكيد الخضراء
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE8F5E9)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(38.dp)
                    )
                }

                Text(
                    text = "تم الشراء وتوريد البضائع بنجاح! 🛍️",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2E7D32),
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "تم تحديث رفوف دكان الخضار والفواكه بالبضائع الطازجة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // تفاصيل العملية
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("الكمية المضافة للرفوف:", style = MaterialTheme.typography.bodySmall)
                    Text("+$unitsPurchased وحدة", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المبلغ المخصوم:", style = MaterialTheme.typography.bodySmall)
                    Text("-$costDeducted ريال", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المال المتبقي:", style = MaterialTheme.typography.bodySmall)
                    Text("$remainingCash ريال", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("رائع، حسناً")
                }
            }
        }
    }
}
