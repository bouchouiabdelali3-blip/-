package com.example.game.model

/**
 * اتجاه أسعار السوق بالجملة (نظام الأسعار الديناميكية)
 */
enum class PriceTrend(val labelAr: String, val symbol: String) {
    STABLE("مستقر", "➡️"),
    RISING("مرتفع", "📈"),
    FALLING("منخفض", "📉"),
    DISCOUNT("تخفيض جملة", "🏷️")
}

/**
 * صنف في المخزون (خضار وفواكه)
 * يدعم نظام الأسعار المتغيرة والديناميكية بناءً على تقلبات السوق اليومية
 */
data class InventoryItem(
    val id: String,
    val nameAr: String,
    val categoryAr: String,
    val wholesalePrice: Long, // سعر الشراء الحالي بالجملة (ديناميكي)
    val retailPrice: Long,    // سعر البيع الحالي للزبائن
    val currentStock: Int,    // الكمية الحالية في الدكان
    val maxCapacity: Int,     // سعة التخزين القصوى
    val iconEmoji: String,
    val baseWholesalePrice: Long = wholesalePrice, // السعر المرجعي الأساسي بالجملة
    val baseRetailPrice: Long = retailPrice,       // السعر المرجعي الأساسي للتجزئة
    val priceTrend: PriceTrend = PriceTrend.STABLE, // اتجاه السعر اليوم
    val priceChangePercent: Int = 0                 // نسبة التغير مقارنة بالسعر الأساسي (مثل +15% أو -10%)
)

/**
 * معدات المتجر
 */
data class StoreEquipment(
    val id: String,
    val nameAr: String,
    val descriptionAr: String,
    val level: Int,
    val maxLevel: Int = 3,
    val upgradeCost: Long,
    val customerBonusPercent: Int, // زيادة إقبال الزبائن
    val iconEmoji: String
)

/**
 * بيانات متجر الخضار والفواكه
 */
data class Store(
    val id: String,
    val nameAr: String,
    val locationAr: String,
    val reputation: Int, // السمعة التجارية (0 - 100)
    val dailyFootTraffic: Int, // عدد الزبائن المتوقع يومياً
    val equipments: List<StoreEquipment>,
    val isOpen: Boolean = true
)

