package com.example.game.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameSaveDao {
    @Query("SELECT * FROM game_saves WHERE id = 1 LIMIT 1")
    fun getGameSaveFlow(): Flow<GameSaveEntity?>

    @Query("SELECT * FROM game_saves WHERE id = 1 LIMIT 1")
    suspend fun getGameSaveOnce(): GameSaveEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSave(save: GameSaveEntity)

    @Query("DELETE FROM game_saves WHERE id = 1")
    suspend fun deleteSave()
}
