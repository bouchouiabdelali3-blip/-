package com.example.game.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_saves")
data class GameSaveEntity(
    @PrimaryKey val id: Int = 1,
    val day: Int,
    val cash: Long,
    val storeName: String,
    val jsonState: String,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)
