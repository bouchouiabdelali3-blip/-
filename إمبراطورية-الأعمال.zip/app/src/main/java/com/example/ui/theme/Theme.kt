package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldLight,
    onPrimary = Color.Black,
    primaryContainer = EmeraldDark,
    onPrimaryContainer = EmeraldContainer,
    secondary = GoldLight,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF5A3E00),
    onSecondaryContainer = GoldContainer,
    tertiary = WoodBrown,
    background = DarkBg,
    onBackground = Color(0xFFE2EBE5),
    surface = DarkSurface,
    onSurface = Color(0xFFE2EBE5),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFC2CDC7),
    outline = Color(0xFF42544A)
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldDark,
    secondary = GoldSecondary,
    onSecondary = Color.White,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = Color(0xFF452C00),
    tertiary = WoodBrown,
    background = WarmSandBg,
    onBackground = TextPrimaryDark,
    surface = WarmSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = WarmSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = OutlineWarm
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
