package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان لعبة "حياة الأعمال" (Business Life) - طابع زراعي وتجاري ريفي ودافئ
val EmeraldPrimary = Color(0xFF1B5E20)
val EmeraldDark = Color(0xFF0E3813)
val EmeraldLight = Color(0xFF4CAF50)
val EmeraldContainer = Color(0xFFC8E6C9)

val GoldSecondary = Color(0xFFF57F17)
val GoldLight = Color(0xFFFFD54F)
val GoldContainer = Color(0xFFFFF9C4)

val WoodBrown = Color(0xFF5D4037)
val WarmSandBg = Color(0xFFFBF9F3)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceVariant = Color(0xFFF1EDE4)
val OutlineWarm = Color(0xFFD7CCC8)

val DarkBg = Color(0xFF0F1A14)
val DarkSurface = Color(0xFF16251E)
val DarkSurfaceVariant = Color(0xFF213329)

val TextPrimaryDark = Color(0xFF1E2621)
val TextSecondaryDark = Color(0xFF4A554E)

val SuccessGreen = Color(0xFF2E7D32)
val DangerRed = Color(0xFFC62828)
val InfoBlue = Color(0xFF1565C0)
